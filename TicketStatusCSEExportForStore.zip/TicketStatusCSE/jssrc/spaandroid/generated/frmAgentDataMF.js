function addWidgetsfrmAgentDataMF() {
    frmAgentDataMF.setDefaultUnit(kony.flex.DP);
    var Label04e655f60c7854d = new kony.ui.Label({
        "id": "Label04e655f60c7854d",
        "isVisible": true,
        "left": "50dp",
        "skin": "CopyslLabel0497d03338d8546",
        "text": "last refreshed at ",
        "top": "84%",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "renderAsAnchor": false,
        "textCopyable": false
    });
    var timeStampLabel = new kony.ui.Label({
        "id": "timeStampLabel",
        "isVisible": true,
        "left": "164dp",
        "skin": "CopyslLabel07869ff3974a547",
        "text": "timestamp",
        "top": "84%",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "renderAsAnchor": false,
        "textCopyable": false
    });
    var refreshButton = new kony.ui.Image2({
        "height": "33dp",
        "id": "refreshButton",
        "isVisible": true,
        "left": "8dp",
        "onTouchStart": AS_Image_17bde5db74a345aba50c04124d88691e,
        "skin": "slImage",
        "src": "refreshbutton.png",
        "top": "83%",
        "width": "37dp",
        "zIndex": 1
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var insideFlex = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "8%",
        "id": "insideFlex",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0dp",
        "skin": "CopyslFbox0b3627984c31943",
        "top": "17%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    insideFlex.setDefaultUnit(kony.flex.DP);
    var Label0b657f10096734a = new kony.ui.Label({
        "id": "Label0b657f10096734a",
        "isVisible": true,
        "left": "2%",
        "skin": "CopyslLabel0908910268e204d",
        "text": "Engineer",
        "top": "40%",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "renderAsAnchor": false,
        "textCopyable": false
    });
    var Label001bc1f55ec6744 = new kony.ui.Label({
        "id": "Label001bc1f55ec6744",
        "isVisible": true,
        "left": "40%",
        "skin": "CopyslLabel0b9cb57ed707d46",
        "text": "Open",
        "top": "40%",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "renderAsAnchor": false,
        "textCopyable": false
    });
    var Label00794b501e82947 = new kony.ui.Label({
        "id": "Label00794b501e82947",
        "isVisible": true,
        "left": "60%",
        "skin": "CopyslLabel0c925fd360d244e",
        "text": "Pending",
        "top": "40%",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "renderAsAnchor": false,
        "textCopyable": false
    });
    var CopyLabel08f5dc29d0fa04c = new kony.ui.Label({
        "id": "CopyLabel08f5dc29d0fa04c",
        "isVisible": true,
        "left": "85%",
        "skin": "CopyslLabel0c925fd360d244e",
        "text": "Total",
        "top": "40%",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "renderAsAnchor": false,
        "textCopyable": false
    });
    insideFlex.add(Label0b657f10096734a, Label001bc1f55ec6744, Label00794b501e82947, CopyLabel08f5dc29d0fa04c);
    var footerFlex = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "bottom": "0%",
        "clipBounds": true,
        "height": "7.40%",
        "id": "footerFlex",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0dp",
        "skin": "CopyslFbox0d8613b7525414d",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    footerFlex.setDefaultUnit(kony.flex.DP);
    var btnHome = new kony.ui.Button({
        "height": "60%",
        "id": "btnHome",
        "isVisible": true,
        "left": "1%",
        "onClick": AS_Button_b5722e56dc2447f49c4c32d82d0baad5,
        "skin": "CopyslButtonGlossBlue00b7c3a62349a4d",
        "text": "Home",
        "top": "25%",
        "width": "30%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var btnNextMADP = new kony.ui.Button({
        "height": "60%",
        "id": "btnNextMADP",
        "isVisible": true,
        "onClick": AS_Button_d2b33bfc70f840f582464e250b34afee,
        "right": "1%",
        "skin": "CopyslButtonGlossBlue00b7c3a62349a4d",
        "text": "MADP Status",
        "top": "25%",
        "width": "30%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var refreshPage = new kony.ui.Button({
        "height": "60%",
        "id": "refreshPage",
        "isVisible": true,
        "onClick": AS_Button_fb5cbaa4682b4a4ab2bad282ae7e4a98,
        "right": "35.67%",
        "skin": "CopyslButtonGlossBlue0bc052b1b7c8b45",
        "text": "Refresh",
        "top": "25%",
        "width": "30%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    footerFlex.add(btnHome, btnNextMADP, refreshPage);
    var arifFlex = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "5%",
        "id": "arifFlex",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "skin": "CopyslFbox0cfaa4a8780ee48",
        "top": "25%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    arifFlex.setDefaultUnit(kony.flex.DP);
    var arifOpen = new kony.ui.Label({
        "id": "arifOpen",
        "isVisible": true,
        "left": "42%",
        "skin": "CopyslLabel0372edb8e723b47",
        "text": "-",
        "top": "10dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "renderAsAnchor": false,
        "textCopyable": false
    });
    var arifPending = new kony.ui.Label({
        "id": "arifPending",
        "isVisible": true,
        "left": "62%",
        "skin": "CopyslLabel0759d8f3135f84d",
        "text": "-",
        "top": "10dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "renderAsAnchor": false,
        "textCopyable": false
    });
    var arifTotal = new kony.ui.Label({
        "id": "arifTotal",
        "isVisible": true,
        "left": "85%",
        "skin": "CopyslLabel0372edb8e723b47",
        "text": "-",
        "top": "10dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "renderAsAnchor": false,
        "textCopyable": false
    });
    var Label0d21985708a7a43 = new kony.ui.Label({
        "id": "Label0d21985708a7a43",
        "isVisible": true,
        "left": "2%",
        "skin": "CopyslLabel0794ade92fb164a",
        "text": "Arif",
        "top": "7dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "renderAsAnchor": false,
        "textCopyable": false
    });
    arifFlex.add(arifOpen, arifPending, arifTotal, Label0d21985708a7a43);
    var kushalFlex = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "5%",
        "id": "kushalFlex",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "skin": "CopyslFbox0cbb4b8dfaebf47",
        "top": "30%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    kushalFlex.setDefaultUnit(kony.flex.DP);
    var kushalOpen = new kony.ui.Label({
        "id": "kushalOpen",
        "isVisible": true,
        "left": "42%",
        "skin": "CopyslLabel0372edb8e723b47",
        "text": "-",
        "top": "10dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "renderAsAnchor": false,
        "textCopyable": false
    });
    var kushalPending = new kony.ui.Label({
        "id": "kushalPending",
        "isVisible": true,
        "left": "62%",
        "skin": "CopyslLabel0759d8f3135f84d",
        "text": "-",
        "top": "10dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "renderAsAnchor": false,
        "textCopyable": false
    });
    var kushalTotal = new kony.ui.Label({
        "id": "kushalTotal",
        "isVisible": true,
        "left": "85%",
        "skin": "CopyslLabel0372edb8e723b47",
        "text": "-",
        "top": "10dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "renderAsAnchor": false,
        "textCopyable": false
    });
    var CopyLabel0a67b3065ba0a45 = new kony.ui.Label({
        "id": "CopyLabel0a67b3065ba0a45",
        "isVisible": true,
        "left": "2%",
        "skin": "CopyslLabel0794ade92fb164a",
        "text": "Kushal",
        "top": "6dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "renderAsAnchor": false,
        "textCopyable": false
    });
    kushalFlex.add(kushalOpen, kushalPending, kushalTotal, CopyLabel0a67b3065ba0a45);
    var srikanthMFlex = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "5%",
        "id": "srikanthMFlex",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "skin": "CopyslFbox0fc533fa22c9b4e",
        "top": "35%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    srikanthMFlex.setDefaultUnit(kony.flex.DP);
    var srikanthMOpen = new kony.ui.Label({
        "id": "srikanthMOpen",
        "isVisible": true,
        "left": "42%",
        "skin": "CopyslLabel0372edb8e723b47",
        "text": "-",
        "top": "10dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "renderAsAnchor": false,
        "textCopyable": false
    });
    var srikanthMPending = new kony.ui.Label({
        "id": "srikanthMPending",
        "isVisible": true,
        "left": "62%",
        "skin": "CopyslLabel0759d8f3135f84d",
        "text": "-",
        "top": "10dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "renderAsAnchor": false,
        "textCopyable": false
    });
    var srikanthMTotal = new kony.ui.Label({
        "id": "srikanthMTotal",
        "isVisible": true,
        "left": "85%",
        "skin": "CopyslLabel0372edb8e723b47",
        "text": "-",
        "top": "10dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "renderAsAnchor": false,
        "textCopyable": false
    });
    var CopyLabel090ec2d0f671b4f = new kony.ui.Label({
        "id": "CopyLabel090ec2d0f671b4f",
        "isVisible": true,
        "left": "2%",
        "skin": "CopyslLabel0794ade92fb164a",
        "text": "Sreekanth M",
        "top": "5dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "renderAsAnchor": false,
        "textCopyable": false
    });
    srikanthMFlex.add(srikanthMOpen, srikanthMPending, srikanthMTotal, CopyLabel090ec2d0f671b4f);
    var harishFlex = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "5%",
        "id": "harishFlex",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "skin": "CopyslFbox0cc075cd3378448",
        "top": "40%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    harishFlex.setDefaultUnit(kony.flex.DP);
    var harishOpen = new kony.ui.Label({
        "id": "harishOpen",
        "isVisible": true,
        "left": "42%",
        "skin": "CopyslLabel0372edb8e723b47",
        "text": "-",
        "top": "10dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "renderAsAnchor": false,
        "textCopyable": false
    });
    var harishPending = new kony.ui.Label({
        "id": "harishPending",
        "isVisible": true,
        "left": "62%",
        "skin": "CopyslLabel0759d8f3135f84d",
        "text": "-",
        "top": "10dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "renderAsAnchor": false,
        "textCopyable": false
    });
    var harishTotal = new kony.ui.Label({
        "id": "harishTotal",
        "isVisible": true,
        "left": "85%",
        "skin": "CopyslLabel0372edb8e723b47",
        "text": "-",
        "top": "10dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "renderAsAnchor": false,
        "textCopyable": false
    });
    var CopyLabel0fade3dd5d3f040 = new kony.ui.Label({
        "id": "CopyLabel0fade3dd5d3f040",
        "isVisible": true,
        "left": "2%",
        "skin": "CopyslLabel0794ade92fb164a",
        "text": "Harish",
        "top": "5dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "renderAsAnchor": false,
        "textCopyable": false
    });
    harishFlex.add(harishOpen, harishPending, harishTotal, CopyLabel0fade3dd5d3f040);
    var srikanthDFlex = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "5%",
        "id": "srikanthDFlex",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "skin": "CopyslFbox002e351fe934045",
        "top": "45%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    srikanthDFlex.setDefaultUnit(kony.flex.DP);
    var srikanthDOpen = new kony.ui.Label({
        "id": "srikanthDOpen",
        "isVisible": true,
        "left": "42%",
        "skin": "CopyslLabel0372edb8e723b47",
        "text": "-",
        "top": "10dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "renderAsAnchor": false,
        "textCopyable": false
    });
    var srikanthDPending = new kony.ui.Label({
        "id": "srikanthDPending",
        "isVisible": true,
        "left": "62%",
        "skin": "CopyslLabel0759d8f3135f84d",
        "text": "-",
        "top": "10dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "renderAsAnchor": false,
        "textCopyable": false
    });
    var srikanthDTotal = new kony.ui.Label({
        "id": "srikanthDTotal",
        "isVisible": true,
        "left": "85%",
        "skin": "CopyslLabel0372edb8e723b47",
        "text": "-",
        "top": "10dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "renderAsAnchor": false,
        "textCopyable": false
    });
    var CopyLabel0d29c4fd52e3647 = new kony.ui.Label({
        "id": "CopyLabel0d29c4fd52e3647",
        "isVisible": true,
        "left": "2%",
        "skin": "CopyslLabel0794ade92fb164a",
        "text": "Srikanth D",
        "top": "5dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "renderAsAnchor": false,
        "textCopyable": false
    });
    srikanthDFlex.add(srikanthDOpen, srikanthDPending, srikanthDTotal, CopyLabel0d29c4fd52e3647);
    var sureshBFlex = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "5%",
        "id": "sureshBFlex",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "skin": "CopyslFbox06e29e5ebb47244",
        "top": "50%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    sureshBFlex.setDefaultUnit(kony.flex.DP);
    var sureshBOpen = new kony.ui.Label({
        "id": "sureshBOpen",
        "isVisible": true,
        "left": "42%",
        "skin": "CopyslLabel0372edb8e723b47",
        "text": "-",
        "top": "10dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "renderAsAnchor": false,
        "textCopyable": false
    });
    var sureshBPending = new kony.ui.Label({
        "id": "sureshBPending",
        "isVisible": true,
        "left": "62%",
        "skin": "CopyslLabel0759d8f3135f84d",
        "text": "-",
        "top": "10dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "renderAsAnchor": false,
        "textCopyable": false
    });
    var sureshBTotal = new kony.ui.Label({
        "id": "sureshBTotal",
        "isVisible": true,
        "left": "85%",
        "skin": "CopyslLabel0372edb8e723b47",
        "text": "-",
        "top": "10dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "renderAsAnchor": false,
        "textCopyable": false
    });
    var CopyLabel033c70c1c80734d = new kony.ui.Label({
        "id": "CopyLabel033c70c1c80734d",
        "isVisible": true,
        "left": "2%",
        "skin": "CopyslLabel0794ade92fb164a",
        "text": "Suresh B",
        "top": "5dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "renderAsAnchor": false,
        "textCopyable": false
    });
    sureshBFlex.add(sureshBOpen, sureshBPending, sureshBTotal, CopyLabel033c70c1c80734d);
    var sanaFlex = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "5%",
        "id": "sanaFlex",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "skin": "CopyslFbox044baaf6d3c854d",
        "top": "55%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    sanaFlex.setDefaultUnit(kony.flex.DP);
    var sanaOpen = new kony.ui.Label({
        "id": "sanaOpen",
        "isVisible": true,
        "left": "42%",
        "skin": "CopyslLabel0372edb8e723b47",
        "text": "-",
        "top": "10dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "renderAsAnchor": false,
        "textCopyable": false
    });
    var sanaPending = new kony.ui.Label({
        "id": "sanaPending",
        "isVisible": true,
        "left": "62%",
        "skin": "CopyslLabel0759d8f3135f84d",
        "text": "-",
        "top": "10dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "renderAsAnchor": false,
        "textCopyable": false
    });
    var sanaTotal = new kony.ui.Label({
        "id": "sanaTotal",
        "isVisible": true,
        "left": "85%",
        "skin": "CopyslLabel0372edb8e723b47",
        "text": "-",
        "top": "10dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "renderAsAnchor": false,
        "textCopyable": false
    });
    var CopyLabel0fc70c27f077644 = new kony.ui.Label({
        "id": "CopyLabel0fc70c27f077644",
        "isVisible": true,
        "left": "2%",
        "skin": "CopyslLabel0794ade92fb164a",
        "text": "Sana",
        "top": "5dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "renderAsAnchor": false,
        "textCopyable": false
    });
    sanaFlex.add(sanaOpen, sanaPending, sanaTotal, CopyLabel0fc70c27f077644);
    var ramanaFlex = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "5%",
        "id": "ramanaFlex",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "skin": "CopyslFbox09763de6a5b5a46",
        "top": "60%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    ramanaFlex.setDefaultUnit(kony.flex.DP);
    var ramanaOpen = new kony.ui.Label({
        "id": "ramanaOpen",
        "isVisible": true,
        "left": "42%",
        "skin": "CopyslLabel0372edb8e723b47",
        "text": "-",
        "top": "10dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "renderAsAnchor": false,
        "textCopyable": false
    });
    var ramanaPending = new kony.ui.Label({
        "id": "ramanaPending",
        "isVisible": true,
        "left": "62%",
        "skin": "CopyslLabel0759d8f3135f84d",
        "text": "-",
        "top": "10dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "renderAsAnchor": false,
        "textCopyable": false
    });
    var ramanaTotal = new kony.ui.Label({
        "id": "ramanaTotal",
        "isVisible": true,
        "left": "85%",
        "skin": "CopyslLabel0372edb8e723b47",
        "text": "-",
        "top": "10dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "renderAsAnchor": false,
        "textCopyable": false
    });
    var CopyLabel0c23c1f665bc34d = new kony.ui.Label({
        "id": "CopyLabel0c23c1f665bc34d",
        "isVisible": true,
        "left": "2%",
        "skin": "CopyslLabel0794ade92fb164a",
        "text": "Pothuraju",
        "top": "5dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "renderAsAnchor": false,
        "textCopyable": false
    });
    ramanaFlex.add(ramanaOpen, ramanaPending, ramanaTotal, CopyLabel0c23c1f665bc34d);
    var thilakFlex = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "5%",
        "id": "thilakFlex",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "skin": "CopyslFbox044baaf6d3c854d",
        "top": "65%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    thilakFlex.setDefaultUnit(kony.flex.DP);
    var thilakOpen = new kony.ui.Label({
        "id": "thilakOpen",
        "isVisible": true,
        "left": "42%",
        "skin": "CopyslLabel0372edb8e723b47",
        "text": "-",
        "top": "10dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "renderAsAnchor": false,
        "textCopyable": false
    });
    var thilakPending = new kony.ui.Label({
        "id": "thilakPending",
        "isVisible": true,
        "left": "62%",
        "skin": "CopyslLabel0759d8f3135f84d",
        "text": "-",
        "top": "10dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "renderAsAnchor": false,
        "textCopyable": false
    });
    var thilakTotal = new kony.ui.Label({
        "id": "thilakTotal",
        "isVisible": true,
        "left": "85%",
        "skin": "CopyslLabel0372edb8e723b47",
        "text": "-",
        "top": "10dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "renderAsAnchor": false,
        "textCopyable": false
    });
    var CopyLabel016216395430f40 = new kony.ui.Label({
        "id": "CopyLabel016216395430f40",
        "isVisible": true,
        "left": "2%",
        "skin": "CopyslLabel0794ade92fb164a",
        "text": "Thilak",
        "top": "5dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "renderAsAnchor": false,
        "textCopyable": false
    });
    thilakFlex.add(thilakOpen, thilakPending, thilakTotal, CopyLabel016216395430f40);
    var nareshFlex = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "5%",
        "id": "nareshFlex",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0.00%",
        "skin": "CopyslFbox09763de6a5b5a46",
        "top": "70%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    nareshFlex.setDefaultUnit(kony.flex.DP);
    var nareshOpen = new kony.ui.Label({
        "id": "nareshOpen",
        "isVisible": true,
        "left": "42%",
        "skin": "CopyslLabel0372edb8e723b47",
        "text": "-",
        "top": "10dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "renderAsAnchor": false,
        "textCopyable": false
    });
    var nareshPending = new kony.ui.Label({
        "id": "nareshPending",
        "isVisible": true,
        "left": "62%",
        "skin": "CopyslLabel0759d8f3135f84d",
        "text": "-",
        "top": "10dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "renderAsAnchor": false,
        "textCopyable": false
    });
    var nareshTotal = new kony.ui.Label({
        "id": "nareshTotal",
        "isVisible": true,
        "left": "85%",
        "skin": "CopyslLabel0372edb8e723b47",
        "text": "-",
        "top": "10dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "renderAsAnchor": false,
        "textCopyable": false
    });
    var CopyLabel0d96661e777434e = new kony.ui.Label({
        "id": "CopyLabel0d96661e777434e",
        "isVisible": true,
        "left": "2%",
        "skin": "CopyslLabel0794ade92fb164a",
        "text": "Naresh N",
        "top": "5dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "renderAsAnchor": false,
        "textCopyable": false
    });
    nareshFlex.add(nareshOpen, nareshPending, nareshTotal, CopyLabel0d96661e777434e);
    var FlexContainer039988780bbb143 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "7%",
        "id": "FlexContainer039988780bbb143",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0dp",
        "skin": "CopyslFbox04313620086a946",
        "top": "10%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    FlexContainer039988780bbb143.setDefaultUnit(kony.flex.DP);
    var Label07cb3e6aadc9340 = new kony.ui.Label({
        "id": "Label07cb3e6aadc9340",
        "isVisible": true,
        "left": "2%",
        "skin": "CopyslLabel0fe937e20284b43",
        "text": "MF Status",
        "top": "5%",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "renderAsAnchor": false,
        "textCopyable": false
    });
    var CopyLabel04c7a2a04f37044 = new kony.ui.Label({
        "id": "CopyLabel04c7a2a04f37044",
        "isVisible": true,
        "right": "2%",
        "skin": "CopyslLabel0fe937e20284b43",
        "text": "Page 1/1",
        "top": "5%",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "renderAsAnchor": false,
        "textCopyable": false
    });
    FlexContainer039988780bbb143.add(Label07cb3e6aadc9340, CopyLabel04c7a2a04f37044);
    var kmebab0e1bdcf4025968576e3c1751f5b = new kony.ui.FlexContainer({
        "isMaster": true,
        "height": "10%",
        "id": "masterFlexHeader",
        "left": "0dp",
        "top": "0dp",
        "width": "100%",
        "zIndex": 1,
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "skin": "slFbox"
    }, {}, {});
    kmebab0e1bdcf4025968576e3c1751f5b.setDefaultUnit(kony.flex.DP);
    var kmdf38d774afe4d2d9ffeb966c4a26209 = new kony.ui.FlexContainer({
        "height": "100%",
        "id": "FlexContainer06c89085ee5754a",
        "left": "0dp",
        "top": "0dp",
        "width": "100%",
        "zIndex": 1,
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "skin": "CopyslFbox0b823aeeea1ee45"
    }, {}, {});
    kmdf38d774afe4d2d9ffeb966c4a26209.setDefaultUnit(kony.flex.DP);
    var kme62065fd61f4868817f44df01d0c9ab = new kony.ui.Label({
        "id": "Label0bb5fed64490342",
        "left": "20%",
        "text": "CSE Ticket Status",
        "top": "25%",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1,
        "isVisible": true,
        "skin": "CopyslLabel058b3abcc5c3946"
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "renderAsAnchor": false,
        "textCopyable": false
    });
    var kmc39ded9be2f40e9b07cf15dbaf758a1 = new kony.ui.Image2({
        "height": "20dp",
        "id": "Image0ee368462a3764e",
        "left": 0,
        "right": 0,
        "src": "kony_logo2x.png",
        "top": "4dp",
        "width": "60dp",
        "zIndex": 1,
        "isVisible": true,
        "skin": "slImage"
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    kmdf38d774afe4d2d9ffeb966c4a26209.add(kme62065fd61f4868817f44df01d0c9ab, kmc39ded9be2f40e9b07cf15dbaf758a1);
    kmebab0e1bdcf4025968576e3c1751f5b.add(kmdf38d774afe4d2d9ffeb966c4a26209);
    var mallikarjunaFlex = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "5%",
        "id": "mallikarjunaFlex",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "skin": "CopyslFbox0cfaa4a8780ee48",
        "top": "75%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    mallikarjunaFlex.setDefaultUnit(kony.flex.DP);
    var mallikarjunaOpen = new kony.ui.Label({
        "id": "mallikarjunaOpen",
        "isVisible": true,
        "left": "42%",
        "skin": "CopyslLabel0372edb8e723b47",
        "text": "-",
        "top": "10dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "renderAsAnchor": false,
        "textCopyable": false
    });
    var mallikarjunaPending = new kony.ui.Label({
        "id": "mallikarjunaPending",
        "isVisible": true,
        "left": "62%",
        "skin": "CopyslLabel0759d8f3135f84d",
        "text": "-",
        "top": "10dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "renderAsAnchor": false,
        "textCopyable": false
    });
    var mallikarjunaTotal = new kony.ui.Label({
        "id": "mallikarjunaTotal",
        "isVisible": true,
        "left": "85%",
        "skin": "CopyslLabel0372edb8e723b47",
        "text": "-",
        "top": "10dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "renderAsAnchor": false,
        "textCopyable": false
    });
    var CopyLabel0a84f43954a7648 = new kony.ui.Label({
        "id": "CopyLabel0a84f43954a7648",
        "isVisible": true,
        "left": "2%",
        "skin": "CopyslLabel0794ade92fb164a",
        "text": "Mallikarjuna",
        "top": "7dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "renderAsAnchor": false,
        "textCopyable": false
    });
    mallikarjunaFlex.add(mallikarjunaOpen, mallikarjunaPending, mallikarjunaTotal, CopyLabel0a84f43954a7648);
    frmAgentDataMF.add(Label04e655f60c7854d, timeStampLabel, refreshButton, insideFlex, footerFlex, arifFlex, kushalFlex, srikanthMFlex, harishFlex, srikanthDFlex, sureshBFlex, sanaFlex, ramanaFlex, thilakFlex, nareshFlex, FlexContainer039988780bbb143, kmebab0e1bdcf4025968576e3c1751f5b, mallikarjunaFlex);
};

function frmAgentDataMFGlobals() {
    frmAgentDataMF = new kony.ui.Form2({
        "addWidgets": addWidgetsfrmAgentDataMF,
        "enabledForIdleTimeout": false,
        "id": "frmAgentDataMF",
        "init": AS_Form_eb7c4707d2c2456e8faeae174b299189,
        "layoutType": kony.flex.FREE_FORM,
        "needAppMenu": false,
        "preShow": AS_Form_e4cb4ca87edd4ed48153bced716b1dab,
        "skin": "CopyslForm028c735bf23e94b"
    }, {
        "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
        "layoutType": kony.flex.FREE_FORM,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "inTransitionConfig": {
            "formTransition": "bottomCenter"
        },
        "outTransitionConfig": {
            "transitionDirection": "fromRight",
            "transitionDuration": 0.3,
            "transitionEffect": "transitionCloth"
        },
        "retainScrollPosition": false
    });
};