kony.globals["appid"] = "TicketStatusCSE";
kony.globals["locales"] = [];