//Type your code here
var configuration = {
    "appKey": "7646a1347e33f9b13d5297aeb2ed9dd1",
    "appSecret": "10a1bf51c16ee35157bdbef574cab87e",
    //"serviceURL": "http://KH9331.kitspl.com:8080/authService/100000002/appconfig",
    "serviceURL": "https://productsupport.konylabs.net/authService/100000002/appconfig",
    "orchestrationService": {
        "serviceName": "Orch"
    }
};

function minitiateMF() // works for daily
{
    //kony.application.showLoadingScreen("skinLoading", "Loading", constants.LOADING_SCREEN_POSITION_ONLY_CENTER, true, true, {
    //     shouldShowLabelInBottom: "true",enableMenuKey: false,
    //    enableBackKey: false
    // }); 
    mclient = new kony.sdk();
    mclient.init(configuration.appKey, configuration.appSecret, configuration.serviceURL, function(response) {
        kony.print("Init success");
        alert("Init success");
        mmFSuccess();
    }, function(error) {
        kony.print("Init Failure");
        mmfFailure();
    });
}

function mmFSuccess() {
    obj = mclient.getIntegrationService("ForLogin");
    kony.print("mFsuccess");
    //  menuclick=1;
    // baseurl="http://productsupport.konylabs.net/EmployeePics/";
    //frmLogin.btnLogin.setEnabled(true);
    //frmLogin.btnForgot.setEnabled(true);
    //kony.application.dismissLoadingScreen();
    //updatefirstonly();
    // getDetails();
    //1  operationSuccess();
}

function mmfFailure() {
    alert("please check the network connection");
    frmLogin.btnLogin.setEnabled(false);
    //frmLogin.btnForgot.setEnabled(false);
    kony.print("Error while integrating with mobile Fabric");
    //  kony.application.dismissLoadingScreen();
}
EmployeId = "";

function mauthenticate() {
    obj = mclient.getIntegrationService("ForLogin");
    if ((frmLogin.txtUser.text === "" || frmLogin.txtUser.text === undefined) && (frmLogin.txtPassWord.text === "" || frmLogin.txtPassWord.text === undefined)) {
        alert("please enter your username and password");
    } else if (frmLogin.txtUser.text === "" || frmLogin.txtUser.text === undefined) {
        alert("please enter the username");
    } else if (frmLogin.txtPassWord.text === "" || frmLogin.txtPassWord.text === undefined) {
        alert("please enter the password");
    } else {
        operationName = "csedatabase_login_read";
        EmployeId = frmLogin.txtUser.text.trim();
        var s = "EmployeeID eq " + frmLogin.txtUser.text.trim().toUpperCase() + " and PassWord eq " + md5(frmLogin.txtPassWord.text);
        data = {
            "$filter": s
        };
        headers = {};
        options = {
            "httpRequestOptions": {
                "timeoutIntervalForRequest": 600,
                "timeoutIntervalForResource": 2000
            }
        };
        obj.invokeOperation(operationName, headers, data, function(response) {
            if (response.login.length === 0) {
                alert("please enter the valid credentails 1");
            } else {
                if (response.login[0].Active !== "Yes") {
                    alert("please enter the valid credentails 2");
                } else {
                    Employeename = response.login[0].UserName;
                    frmHomePage.show();
                }
            }
        }, function(err) {
            alert(err);
        }, options);
    }
}