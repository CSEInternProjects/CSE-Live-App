//Type your code here
function regFailureAndroidCallback() {
    kony.print("regFailureAndroidCallback");
    alert("regFailureAndroidCallback");
}

function onlinePushNotificationAndroidCallback(payLoad) {
    kony.print("onlinePushNotificationAndroidCallback");
    alert("onlinePushNotificationAndroidCallback");
    //alert(payLoad.content);
    //alert(JSON.stringify(payLoad));
    pushHandle(payLoad);
}

function offlinePushNotificationAndroidCallback(payLoad) {
    kony.print("offlinePushNotificationAndroidCallback");
    alert("offlinePushNotificationAndroidCallback");
    //alert(payLoad.title);
    //alert(JSON.stringify(payLoad));
    pushHandle(payLoad);
}

function pushHandle(payLoad) {
    //frmHomePage.lblNoteTitle.text=payLoad.title;
    frmHomePage.lblNoteData.text = payLoad.content;
    var pushString = kony.store.getItem("pushList");
    var tempStringPayLoad = JSON.stringify(payLoad);
    if (pushString !== null) pushString = ",".concat(pushString);
    else pushString = "";
    pushString = tempStringPayLoad.concat(pushString);
    kony.store.setItem("pushList", pushString);
    pushString = kony.store.getItem("pushList");
    pushString = "{\"dataSet\":[" + pushString + "]}";
    alert(pushString);
    var test = JSON.parse(pushString);
    var frontNoteSeg = {
        dataSet: []
    };
    /* for(var i=0;(test.dataSet[i]!==null)&&i<2;i++)//
     {
       frontNoteSeg.dataSet[i]=test.dataSet[i];
     }
     */
    frmHomePage.segPush.widgetDataMap = {
        lblSegHeadTitle: "title",
        lblSegContent: "content"
    };
    frmHomePage.segPush.setData(test.dataSet);
    //alert(JSON.stringify(test)); 
}

function unregSuccessAndroidCallback() {
    kony.print("unregSuccessAndroidCallback");
    alert("unregSuccessAndroidCallback");
}

function unregFailureAndroidCallback() {
    kony.print("unregFailureAndroidCallback");
    alert("unregFailureAndroidCallback");
}

function deregister() {
    try {
        messagingClient = KNYMobileFabric.getMessagingService();
    } catch (exception) {
        kony.print("Exception" + exception.message);
    }
    messagingClient.unregister(function(response) {
        kony.print("Unregistration Success " + JSON.stringify(response));
        if (kony.store.getItem("isFirstTime2") !== null) kony.store.removeItem("isFirstTime2");
        frmHomePage.segPush.setVisibility(false);
        frmHomePage.segPush.removeAll();
        kony.store.removeItem("pushList");
        frmHomePage.flxPush.setVisibility(true);
        frmHomePage.imgUnsubscribe.setVisibility(false);
        //frmHomePage.flxNotePrint.setVisibility(false);
        alert("Unregistration Success " + JSON.stringify(response));
    }, function(error) {
        kony.print("Unregistration Failure " + JSON.stringify(error));
        alert("Unregistration Failure " + JSON.stringify(error));
    });
}
//Animation
/*function fetchMessages() {
 var start = 0;
 var perpage = 100;
 var jsonBody = {
  "ufid": "test@kony.com",
  "appId": "0c07f417-42ae-4dd8-a738-672872afbf06",
  "startElement": start,
  "elementsPerPage": perpage
 };
 var url =  + "http://productsupport.konylabs.net/api/v1/messages/fetch";
 var request = new kony.net.HttpRequest();
 request.onReadyStateChange = fetchMessagesSucessCalllback;
 request.open(constants.HTTP_METHOD_POST, url, true);
 request.setRequestHeader("Content-Type", "application/json");
 request.setRequestHeader("X-Device-AuthToken", "your_auth_token_if_set");
 request.send(jsonBody);
}
function fetchMessagesSucessCalllback() {
 if (this.readyState == constants.HTTP_READY_STATE_DONE) {
  var fetchMsgs = this.response;
  if (this.status == 200) {
   alert("Fetched All Messages!")
  } else {
   alert("Error fetching push records.");
  }
 }
}
*/