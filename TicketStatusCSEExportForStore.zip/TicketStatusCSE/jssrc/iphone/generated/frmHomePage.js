function addWidgetsfrmHomePage() {
    frmHomePage.setDefaultUnit(kony.flex.DP);
    var mainFlex = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "100%",
        "id": "mainFlex",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0dp",
        "skin": "CopyslFbox08ad94c534d344d",
        "top": "0dp",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    mainFlex.setDefaultUnit(kony.flex.DP);
    var openLabel = new kony.ui.Label({
        "height": "4%",
        "id": "openLabel",
        "isVisible": true,
        "left": "1%",
        "skin": "CopyslLabel0276f127cbb974f",
        "text": "Open",
        "top": "15%",
        "width": "25%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [1, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var pendingLabel = new kony.ui.Label({
        "height": "4%",
        "id": "pendingLabel",
        "isVisible": true,
        "left": "1%",
        "skin": "CopyslLabel0276f127cbb974f",
        "text": "Pending",
        "top": "20%",
        "width": "25%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [1, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var pendingCount = new kony.ui.Label({
        "height": "4%",
        "id": "pendingCount",
        "isVisible": true,
        "left": "40%",
        "onTouchStart": AS_Label_14ae504eec074a288ef4cd29e6aaa378,
        "skin": "CopyslLabel0805167a2f5204a",
        "text": "-",
        "top": "20%",
        "width": "15%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var openCount = new kony.ui.Label({
        "height": "4%",
        "id": "openCount",
        "isVisible": true,
        "left": "40%",
        "onTouchStart": AS_Label_31f2dfec7dc648b3a0592e978e5fccc5,
        "skin": "CopyslLabel0805167a2f5204a",
        "text": "-",
        "top": "15%",
        "width": "15%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var unAsssignedLabel = new kony.ui.Label({
        "height": "4%",
        "id": "unAsssignedLabel",
        "isVisible": true,
        "left": "1%",
        "skin": "CopyslLabel0276f127cbb974f",
        "text": "Unassigned",
        "top": "32%",
        "width": "25%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [1, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var No1stLabel = new kony.ui.Label({
        "height": "6%",
        "id": "No1stLabel",
        "isVisible": true,
        "left": "1%",
        "skin": "CopyslLabel0276f127cbb974f",
        "text": "No 1st Response",
        "top": "25%",
        "width": "36%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [1, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var escalatedLabel = new kony.ui.Label({
        "height": "6%",
        "id": "escalatedLabel",
        "isVisible": true,
        "left": "1%",
        "skin": "CopyslLabel0276f127cbb974f",
        "text": "Escalated",
        "top": "47%",
        "width": "25%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [1, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var hotlistedLabel = new kony.ui.Label({
        "height": "6%",
        "id": "hotlistedLabel",
        "isVisible": true,
        "left": "1%",
        "skin": "CopyslLabel0276f127cbb974f",
        "text": "Hotlisted",
        "top": "53%",
        "width": "25%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [1, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var othersLabel = new kony.ui.Label({
        "height": "6%",
        "id": "othersLabel",
        "isVisible": true,
        "left": "1.00%",
        "skin": "CopyslLabel0276f127cbb974f",
        "text": "Others",
        "top": "59.98%",
        "width": "25%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [1, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var unAssignedCount = new kony.ui.Label({
        "height": "4%",
        "id": "unAssignedCount",
        "isVisible": true,
        "left": "40%",
        "skin": "CopyslLabel0805167a2f5204a",
        "text": "-",
        "top": "32%",
        "width": "15%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var no1stCount = new kony.ui.Label({
        "height": "6%",
        "id": "no1stCount",
        "isVisible": true,
        "left": "40%",
        "skin": "CopyslLabel0805167a2f5204a",
        "text": "-",
        "top": "25%",
        "width": "15%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var escalatedCount = new kony.ui.Label({
        "height": "6%",
        "id": "escalatedCount",
        "isVisible": true,
        "left": "40%",
        "skin": "CopyslLabel0805167a2f5204a",
        "text": "-",
        "top": "47%",
        "width": "15%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var hotlistedCount = new kony.ui.Label({
        "height": "6%",
        "id": "hotlistedCount",
        "isVisible": true,
        "left": "40%",
        "skin": "CopyslLabel0805167a2f5204a",
        "text": "-",
        "top": "53%",
        "width": "15%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var othersCount = new kony.ui.Label({
        "height": "6%",
        "id": "othersCount",
        "isVisible": true,
        "left": "40%",
        "skin": "CopyslLabel0805167a2f5204a",
        "text": "-",
        "top": "60%",
        "width": "15%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var callbacksla = new kony.ui.Label({
        "height": "5%",
        "id": "callbacksla",
        "isVisible": true,
        "left": "0%",
        "skin": "CopyslLabel0f0e914b625a04a",
        "text": "Callback SLA Breached",
        "top": "40%",
        "width": "100%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var openMFMADP = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "4%",
        "id": "openMFMADP",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "right": 0,
        "skin": "CopyslFbox05bf5c0f0ae8948",
        "top": "15%",
        "width": "40%",
        "zIndex": 1
    }, {}, {});
    openMFMADP.setDefaultUnit(kony.flex.DP);
    var mfopenCount = new kony.ui.Label({
        "bottom": "12%",
        "id": "mfopenCount",
        "isVisible": true,
        "left": "13dp",
        "skin": "CopyslLabel0b57552f383914b",
        "text": "-",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var madpopenCount = new kony.ui.Label({
        "bottom": "12%",
        "id": "madpopenCount",
        "isVisible": true,
        "left": "70%",
        "skin": "CopyslLabel0b57552f383914b",
        "text": "-",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    openMFMADP.add(mfopenCount, madpopenCount);
    var pendingMFMADP = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "4%",
        "id": "pendingMFMADP",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "right": 0,
        "skin": "CopyslFbox05bf5c0f0ae8948",
        "top": "20%",
        "width": "40%",
        "zIndex": 1
    }, {}, {});
    pendingMFMADP.setDefaultUnit(kony.flex.DP);
    var mfPending = new kony.ui.Label({
        "bottom": "12%",
        "id": "mfPending",
        "isVisible": true,
        "left": "13dp",
        "skin": "CopyslLabel0b57552f383914b",
        "text": "-",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var madpPending = new kony.ui.Label({
        "bottom": "12%",
        "id": "madpPending",
        "isVisible": true,
        "left": "70%",
        "skin": "CopyslLabel0b57552f383914b",
        "text": "-",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    pendingMFMADP.add(mfPending, madpPending);
    var no1stMFMADP = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "4%",
        "id": "no1stMFMADP",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "right": 0,
        "skin": "CopyslFbox05bf5c0f0ae8948",
        "top": "26%",
        "width": "40%",
        "zIndex": 1
    }, {}, {});
    no1stMFMADP.setDefaultUnit(kony.flex.DP);
    var mfNo1st = new kony.ui.Label({
        "bottom": "12%",
        "id": "mfNo1st",
        "isVisible": true,
        "left": "13dp",
        "skin": "CopyslLabel0b57552f383914b",
        "text": "-",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var madpno1st = new kony.ui.Label({
        "bottom": "12%",
        "id": "madpno1st",
        "isVisible": true,
        "left": "70%",
        "skin": "CopyslLabel0b57552f383914b",
        "text": "-",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    no1stMFMADP.add(mfNo1st, madpno1st);
    var headingMFMADP = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "5%",
        "id": "headingMFMADP",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "right": 0,
        "skin": "CopyslFbox06aa8bf30423c47",
        "top": "10%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    headingMFMADP.setDefaultUnit(kony.flex.DP);
    var Label0c4569c0fccae44 = new kony.ui.Label({
        "id": "Label0c4569c0fccae44",
        "isVisible": true,
        "left": "63%",
        "skin": "CopyslLabel0ab350f81eab64c",
        "text": "MF",
        "top": "10%",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var CopyLabel053b07b26339247 = new kony.ui.Label({
        "id": "CopyLabel053b07b26339247",
        "isVisible": true,
        "left": "85%",
        "skin": "CopyslLabel03cc10840147f49",
        "text": "MADP",
        "top": "10%",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var CopyLabel031c0ec127b0948 = new kony.ui.Label({
        "id": "CopyLabel031c0ec127b0948",
        "isVisible": true,
        "left": "2%",
        "skin": "CopyslLabel0ab350f81eab64c",
        "text": "State",
        "top": "10%",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var CopyLabel0a7d7c0bbd07142 = new kony.ui.Label({
        "id": "CopyLabel0a7d7c0bbd07142",
        "isVisible": true,
        "left": "42%",
        "skin": "CopyslLabel0ab350f81eab64c",
        "text": "Total",
        "top": "10%",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    headingMFMADP.add(Label0c4569c0fccae44, CopyLabel053b07b26339247, CopyLabel031c0ec127b0948, CopyLabel0a7d7c0bbd07142);
    var escalatedMFMADP = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "6%",
        "id": "escalatedMFMADP",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "right": 0,
        "skin": "CopyslFbox05bf5c0f0ae8948",
        "top": "46%",
        "width": "40%",
        "zIndex": 1
    }, {}, {});
    escalatedMFMADP.setDefaultUnit(kony.flex.DP);
    var escMF = new kony.ui.Label({
        "bottom": "10%",
        "id": "escMF",
        "isVisible": true,
        "left": "13dp",
        "skin": "CopyslLabel0b57552f383914b",
        "text": "-",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var escMADP = new kony.ui.Label({
        "bottom": "10%",
        "id": "escMADP",
        "isVisible": true,
        "left": "70%",
        "skin": "CopyslLabel0b57552f383914b",
        "text": "-",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    escalatedMFMADP.add(escMF, escMADP);
    var hotlistedMFMADP = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "4%",
        "id": "hotlistedMFMADP",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "right": 0,
        "skin": "CopyslFbox05bf5c0f0ae8948",
        "top": "54%",
        "width": "40%",
        "zIndex": 1
    }, {}, {});
    hotlistedMFMADP.setDefaultUnit(kony.flex.DP);
    var hotMF = new kony.ui.Label({
        "bottom": "10%",
        "id": "hotMF",
        "isVisible": true,
        "left": "13dp",
        "skin": "CopyslLabel0b57552f383914b",
        "text": "-",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var hotMADP = new kony.ui.Label({
        "bottom": "10%",
        "id": "hotMADP",
        "isVisible": true,
        "left": "70%",
        "skin": "CopyslLabel0b57552f383914b",
        "text": "-",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    hotlistedMFMADP.add(hotMF, hotMADP);
    var othersMFMADP = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "6%",
        "id": "othersMFMADP",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "right": 0,
        "skin": "CopyslFbox05bf5c0f0ae8948",
        "top": "60%",
        "width": "40%",
        "zIndex": 1
    }, {}, {});
    othersMFMADP.setDefaultUnit(kony.flex.DP);
    var othMF = new kony.ui.Label({
        "bottom": "25%",
        "id": "othMF",
        "isVisible": true,
        "left": "13dp",
        "skin": "CopyslLabel0b57552f383914b",
        "text": "-",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var othMADP = new kony.ui.Label({
        "bottom": "25%",
        "id": "othMADP",
        "isVisible": true,
        "left": "70%",
        "skin": "CopyslLabel0b57552f383914b",
        "text": "-",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    othersMFMADP.add(othMF, othMADP);
    mainFlex.add(openLabel, pendingLabel, pendingCount, openCount, unAsssignedLabel, No1stLabel, escalatedLabel, hotlistedLabel, othersLabel, unAssignedCount, no1stCount, escalatedCount, hotlistedCount, othersCount, callbacksla, openMFMADP, pendingMFMADP, no1stMFMADP, headingMFMADP, escalatedMFMADP, hotlistedMFMADP, othersMFMADP);
    var Label04e655f60c7854d = new kony.ui.Label({
        "id": "Label04e655f60c7854d",
        "isVisible": true,
        "left": "50dp",
        "skin": "CopyslLabel0497d03338d8546",
        "text": "last auto-refreshed at",
        "top": "84%",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var timeStampLabel = new kony.ui.Label({
        "id": "timeStampLabel",
        "isVisible": true,
        "left": "190dp",
        "skin": "CopyslLabel07869ff3974a547",
        "text": "timestamp",
        "top": "84%",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var refreshButton = new kony.ui.Image2({
        "height": "33dp",
        "id": "refreshButton",
        "isVisible": true,
        "left": "1%",
        "skin": "slImage",
        "src": "refreshbutton.png",
        "top": "82%",
        "width": "37dp",
        "zIndex": 1
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var footerFlex = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "bottom": "0%",
        "clipBounds": true,
        "height": "7%",
        "id": "footerFlex",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0dp",
        "skin": "CopyslFbox0d8613b7525414d",
        "top": "93%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    footerFlex.setDefaultUnit(kony.flex.DP);
    var gotoMADP = new kony.ui.Button({
        "height": "60%",
        "id": "gotoMADP",
        "isVisible": true,
        "left": "5%",
        "onClick": AS_Button_8279e0c1736f48678e7c908a066b62be,
        "skin": "CopyslButtonGlossBlue00b7c3a62349a4d",
        "text": "MADP Status",
        "top": "25%",
        "width": "40%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "showProgressIndicator": true
    });
    var gotoMF = new kony.ui.Button({
        "height": "60%",
        "id": "gotoMF",
        "isVisible": true,
        "onClick": AS_Button_e5d9820e69f94c29bed447ffc7781f2d,
        "right": "5%",
        "skin": "CopyslButtonGlossBlue00b7c3a62349a4d",
        "text": "MF Status",
        "top": "25%",
        "width": "40%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "showProgressIndicator": true
    });
    footerFlex.add(gotoMADP, gotoMF);
    var km51aff5a22a54c7aad72853ad2868c97 = new kony.ui.FlexContainer({
        "isMaster": true,
        "height": "10%",
        "id": "masterFlexHeader",
        "left": "0dp",
        "top": "0dp",
        "width": "100%",
        "zIndex": 1,
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "skin": "slFbox"
    }, {}, {});
    km51aff5a22a54c7aad72853ad2868c97.setDefaultUnit(kony.flex.DP);
    var km77682f522d84c4a9d577bdc84d73f05 = new kony.ui.FlexContainer({
        "height": "100%",
        "id": "FlexContainer06c89085ee5754a",
        "left": "0dp",
        "top": "0dp",
        "width": "100%",
        "zIndex": 1,
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "skin": "CopyslFbox0b823aeeea1ee45"
    }, {}, {});
    km77682f522d84c4a9d577bdc84d73f05.setDefaultUnit(kony.flex.DP);
    var km72653521a5948d1b9e47ad2bdffc5d9 = new kony.ui.Label({
        "id": "Label0bb5fed64490342",
        "left": "20%",
        "text": "CSE Ticket Status",
        "top": "30%",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1,
        "isVisible": true,
        "skin": "CopyslLabel058b3abcc5c3946"
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var kmeabf148d56a4a589b5191c3081c3ed6 = new kony.ui.Image2({
        "height": "20dp",
        "id": "Image0ee368462a3764e",
        "left": 0,
        "right": 0,
        "src": "kony_logo2x.png",
        "top": "4dp",
        "width": "60dp",
        "zIndex": 1,
        "isVisible": true,
        "skin": "slImage"
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    km77682f522d84c4a9d577bdc84d73f05.add(km72653521a5948d1b9e47ad2bdffc5d9, kmeabf148d56a4a589b5191c3081c3ed6);
    km51aff5a22a54c7aad72853ad2868c97.add(km77682f522d84c4a9d577bdc84d73f05);
    frmHomePage.add(mainFlex, Label04e655f60c7854d, timeStampLabel, refreshButton, footerFlex, km51aff5a22a54c7aad72853ad2868c97);
};

function frmHomePageGlobals() {
    frmHomePage = new kony.ui.Form2({
        "addWidgets": addWidgetsfrmHomePage,
        "enabledForIdleTimeout": false,
        "id": "frmHomePage",
        "init": AS_Form_839b78c5a3cd4ae0b317ef2a585fd171,
        "layoutType": kony.flex.FREE_FORM,
        "needAppMenu": false,
        "preShow": AS_Form_1fc77aa7fdb4406b9b2f29451eb0e1b8,
        "skin": "CopyslForm028c735bf23e94b"
    }, {
        "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
        "layoutType": kony.flex.FREE_FORM,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "configureExtendBottom": false,
        "configureExtendTop": false,
        "configureStatusBarStyle": false,
        "footerOverlap": false,
        "formTransparencyDuringPostShow": "100",
        "headerOverlap": false,
        "inputAccessoryViewType": constants.FORM_INPUTACCESSORYVIEW_CANCEL,
        "inTransitionConfig": {
            "transitionDirection": "fromRight",
            "transitionDuration": 0.3,
            "transitionEffect": "transitionCloth"
        },
        "needsIndicatorDuringPostShow": false,
        "outTransitionConfig": {
            "transitionDirection": "fromRight",
            "transitionDuration": 0.3,
            "transitionEffect": "transitionCloth"
        },
        "retainScrollPosition": false,
        "titleBar": false,
        "titleBarSkin": "slTitleBar"
    });
};