//startup.js file
var globalhttpheaders = {};
var appConfig = {
    appId: "TicketStatusCSE",
    appName: "CSE Live",
    appVersion: "1.0.1",
    platformVersion: null,
    serverIp: "10.10.17.140",
    serverPort: "80",
    secureServerPort: "443",
    isDebug: false,
    middlewareContext: "TicketStatusCSE",
    isturlbase: "https://productsupport.konylabs.net/services",
    isMFApp: true,
    appKey: "7646a1347e33f9b13d5297aeb2ed9dd1",
    appSecret: "10a1bf51c16ee35157bdbef574cab87e",
    serviceUrl: "https://productsupport.konylabs.net/authService/100000002/appconfig",
    svcDoc: {
        "appId": "0c07f417-42ae-4dd8-a738-672872afbf06",
        "baseId": "603b91eb-5dda-4d93-8c50-82521718405f",
        "name": "PremiumNotifications",
        "selflink": "https://productsupport.konylabs.net/authService/100000002/appconfig",
        "messagingsvc": {
            "appId": "0c07f417-42ae-4dd8-a738-672872afbf06",
            "url": "https://productsupport.konylabs.net/kpns/api/v1"
        },
        "integsvc": {
            "ForLogin": "https://productsupport.konylabs.net/services/ForLogin"
        },
        "reportingsvc": {
            "custom": "https://productsupport.konylabs.net/services/CMS",
            "session": "https://productsupport.konylabs.net/services/IST"
        },
        "services_meta": {
            "ForLogin": {
                "version": "1.0",
                "url": "https://productsupport.konylabs.net/services/ForLogin",
                "type": "integsvc"
            }
        }
    },
    svcDocRefresh: false,
    svcDocRefreshTimeSecs: -1,
    eventTypes: ["FormEntry", "ServiceRequest", "Error", "Crash"],
    url: "https://productsupport.konylabs.net/admin/TicketStatusCSE/MWServlet",
    secureurl: "https://productsupport.konylabs.net/admin/TicketStatusCSE/MWServlet"
};
sessionID = "";

function appInit(params) {
    skinsInit();
    initializeUserWidgets();
    initializetmpForPush();
    frmAgentDataGlobals();
    frmAgentData2Globals();
    frmAgentDataMFGlobals();
    frmHomePageGlobals();
    frmLoginGlobals();
    setAppBehaviors();
};

function setAppBehaviors() {
    kony.application.setApplicationBehaviors({
        applyMarginPaddingInBCGMode: false,
        adherePercentageStrictly: true,
        retainSpaceOnHide: true,
        marginsIncludedInWidgetContainerWeight: true,
        APILevel: 7000
    })
};

function themeCallBack() {
    initializeGlobalVariables();
    callAppMenu();
    kony.application.setApplicationInitializationEvents({
        preappinit: AS_AppEvents_c4b65b216ab1466584bfad7936dfdec2,
        init: appInit,
        showstartupform: function() {
            frmLogin.show();
        }
    });
};

function loadResources() {
    globalhttpheaders = {};
    sdkInitConfig = {
        "appConfig": appConfig,
        "isMFApp": appConfig.isMFApp,
        "appKey": appConfig.appKey,
        "appSecret": appConfig.appSecret,
        "eventTypes": appConfig.eventTypes,
        "serviceUrl": appConfig.serviceUrl
    }
    kony.setupsdks(sdkInitConfig, onSuccessSDKCallBack, onSuccessSDKCallBack);
};

function onSuccessSDKCallBack() {
    kony.theme.setCurrentTheme("default", themeCallBack, themeCallBack);
}
kony.application.setApplicationMode(constants.APPLICATION_MODE_NATIVE);
//If default locale is specified. This is set even before any other app life cycle event is called.
loadResources();
kony.print = function() {
    return;
};