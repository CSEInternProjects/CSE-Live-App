function initializetmpForPush() {
    FlexContainer0a9c3bdd1281841 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
        "clipBounds": true,
        "id": "FlexContainer0a9c3bdd1281841",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "skin": "slFbox"
    }, {}, {});
    FlexContainer0a9c3bdd1281841.setDefaultUnit(kony.flex.DP);
    var lblSegHeadTitle = new kony.ui.Label({
        "id": "lblSegHeadTitle",
        "isVisible": true,
        "left": "3%",
        "skin": "CopyslLabel0ff233797b73343",
        "text": "Label",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "16dp",
        "width": "90%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var lblSegTitle = new kony.ui.Label({
        "id": "lblSegTitle",
        "isVisible": true,
        "left": "3%",
        "skin": "CopyslLabel0c1729f1841a940",
        "text": "Ticket ID",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "0dp",
        "width": "96.99%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var lblSegHeadContent = new kony.ui.Label({
        "id": "lblSegHeadContent",
        "isVisible": true,
        "left": "3%",
        "skin": "CopyslLabel0d753e6bb649349",
        "text": "Content",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "36dp",
        "width": "100%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var lblSegContent = new kony.ui.Label({
        "id": "lblSegContent",
        "isVisible": true,
        "left": "3.00%",
        "skin": "CopyslLabel0c640e034b6a249",
        "text": "Label",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "54dp",
        "width": "95%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    FlexContainer0a9c3bdd1281841.add(lblSegHeadTitle, lblSegTitle, lblSegHeadContent, lblSegContent);
}