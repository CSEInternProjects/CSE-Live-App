function addWidgetsfrmAgentData() {
    frmAgentData.setDefaultUnit(kony.flex.DP);
    var Label04e655f60c7854d = new kony.ui.Label({
        "id": "Label04e655f60c7854d",
        "isVisible": true,
        "left": "50dp",
        "skin": "CopyslLabel0497d03338d8546",
        "text": "last refreshed at ",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "81%",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var timeStampLabel = new kony.ui.Label({
        "id": "timeStampLabel",
        "isVisible": true,
        "left": "164dp",
        "skin": "CopyslLabel07869ff3974a547",
        "text": "timestamp",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "81%",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var refreshButton = new kony.ui.Image2({
        "height": "33dp",
        "id": "refreshButton",
        "isVisible": true,
        "left": "8dp",
        "onTouchStart": AS_Image_6732d9f3e38948a08a690f6e8c8fd017,
        "skin": "slImage",
        "src": "refreshbutton.png",
        "top": "80%",
        "width": "37dp",
        "zIndex": 1
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var insideFlex = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "8%",
        "id": "insideFlex",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0dp",
        "skin": "CopyslFbox0b3627984c31943",
        "top": "17%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    insideFlex.setDefaultUnit(kony.flex.DP);
    var Label0b657f10096734a = new kony.ui.Label({
        "id": "Label0b657f10096734a",
        "isVisible": true,
        "left": "2%",
        "skin": "CopyslLabel0908910268e204d",
        "text": "Engineer",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "40%",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var Label001bc1f55ec6744 = new kony.ui.Label({
        "id": "Label001bc1f55ec6744",
        "isVisible": true,
        "left": "40%",
        "skin": "CopyslLabel0b9cb57ed707d46",
        "text": "Open",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "40%",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var Label00794b501e82947 = new kony.ui.Label({
        "id": "Label00794b501e82947",
        "isVisible": true,
        "left": "60%",
        "skin": "CopyslLabel0c925fd360d244e",
        "text": "Pending",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "40%",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var CopyLabel08f5dc29d0fa04c = new kony.ui.Label({
        "id": "CopyLabel08f5dc29d0fa04c",
        "isVisible": true,
        "left": "85%",
        "skin": "CopyslLabel0c925fd360d244e",
        "text": "Total",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "40%",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    insideFlex.add(Label0b657f10096734a, Label001bc1f55ec6744, Label00794b501e82947, CopyLabel08f5dc29d0fa04c);
    var footerFlex = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "bottom": "0%",
        "clipBounds": true,
        "height": "7.40%",
        "id": "footerFlex",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0dp",
        "skin": "CopyslFbox0d8613b7525414d",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    footerFlex.setDefaultUnit(kony.flex.DP);
    var btnHome = new kony.ui.Button({
        "height": "60%",
        "id": "btnHome",
        "isVisible": true,
        "left": "0%",
        "onClick": AS_Button_8337ff0ffdbc4b9a8ea9327115da8dfa,
        "skin": "CopyslButtonGlossBlue00b7c3a62349a4d",
        "text": "Home",
        "top": "25%",
        "width": "30%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var btnNextMADP = new kony.ui.Button({
        "height": "60%",
        "id": "btnNextMADP",
        "isVisible": true,
        "onClick": AS_Button_5fdb7f27277e4602bbcc463138d43542,
        "right": "1%",
        "skin": "CopyslButtonGlossBlue00b7c3a62349a4d",
        "text": "Next",
        "top": "25%",
        "width": "30%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var refreshPage = new kony.ui.Button({
        "height": "60%",
        "id": "refreshPage",
        "isVisible": true,
        "onClick": AS_Button_b71574557b30468bad916b70eded4d3d,
        "right": "35.67%",
        "skin": "CopyslButtonGlossBlue0bc052b1b7c8b45",
        "text": "Refresh",
        "top": "25%",
        "width": "30%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    footerFlex.add(btnHome, btnNextMADP, refreshPage);
    var jabiFlex = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "5%",
        "id": "jabiFlex",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "skin": "CopyslFbox0cfaa4a8780ee48",
        "top": "25%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    jabiFlex.setDefaultUnit(kony.flex.DP);
    var jabiOpen = new kony.ui.Label({
        "id": "jabiOpen",
        "isVisible": true,
        "left": "42%",
        "skin": "CopyslLabel0372edb8e723b47",
        "text": "-",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "10dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var jabiPending = new kony.ui.Label({
        "id": "jabiPending",
        "isVisible": true,
        "left": "62%",
        "skin": "CopyslLabel0759d8f3135f84d",
        "text": "-",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "10dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var jabiTotal = new kony.ui.Label({
        "id": "jabiTotal",
        "isVisible": true,
        "left": "85%",
        "skin": "CopyslLabel0372edb8e723b47",
        "text": "-",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "10dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var Label0d21985708a7a43 = new kony.ui.Label({
        "id": "Label0d21985708a7a43",
        "isVisible": true,
        "left": "2%",
        "skin": "CopyslLabel0794ade92fb164a",
        "text": "Jabiulla",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "7dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    jabiFlex.add(jabiOpen, jabiPending, jabiTotal, Label0d21985708a7a43);
    var anuragFlex = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "5%",
        "id": "anuragFlex",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "skin": "CopyslFbox0cbb4b8dfaebf47",
        "top": "30%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    anuragFlex.setDefaultUnit(kony.flex.DP);
    var anuragOpen = new kony.ui.Label({
        "id": "anuragOpen",
        "isVisible": true,
        "left": "42%",
        "skin": "CopyslLabel0372edb8e723b47",
        "text": "-",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "10dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var anuragPending = new kony.ui.Label({
        "id": "anuragPending",
        "isVisible": true,
        "left": "62%",
        "skin": "CopyslLabel0759d8f3135f84d",
        "text": "-",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "10dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var anuragTotal = new kony.ui.Label({
        "id": "anuragTotal",
        "isVisible": true,
        "left": "85%",
        "skin": "CopyslLabel0372edb8e723b47",
        "text": "-",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "10dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var CopyLabel0a67b3065ba0a45 = new kony.ui.Label({
        "id": "CopyLabel0a67b3065ba0a45",
        "isVisible": true,
        "left": "2%",
        "skin": "CopyslLabel0794ade92fb164a",
        "text": "Anurag",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "6dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    anuragFlex.add(anuragOpen, anuragPending, anuragTotal, CopyLabel0a67b3065ba0a45);
    var baluFlex = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "5%",
        "id": "baluFlex",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "skin": "CopyslFbox0fc533fa22c9b4e",
        "top": "35%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    baluFlex.setDefaultUnit(kony.flex.DP);
    var baluOpen = new kony.ui.Label({
        "id": "baluOpen",
        "isVisible": true,
        "left": "42%",
        "skin": "CopyslLabel0372edb8e723b47",
        "text": "-",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "10dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var baluPending = new kony.ui.Label({
        "id": "baluPending",
        "isVisible": true,
        "left": "62%",
        "skin": "CopyslLabel0759d8f3135f84d",
        "text": "-",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "10dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var baluTotal = new kony.ui.Label({
        "id": "baluTotal",
        "isVisible": true,
        "left": "85%",
        "skin": "CopyslLabel0372edb8e723b47",
        "text": "-",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "10dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var CopyLabel090ec2d0f671b4f = new kony.ui.Label({
        "id": "CopyLabel090ec2d0f671b4f",
        "isVisible": true,
        "left": "2%",
        "skin": "CopyslLabel0794ade92fb164a",
        "text": "Lakshmi",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "5dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    baluFlex.add(baluOpen, baluPending, baluTotal, CopyLabel090ec2d0f671b4f);
    var guruFlex = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "5%",
        "id": "guruFlex",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "skin": "CopyslFbox0cc075cd3378448",
        "top": "40%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    guruFlex.setDefaultUnit(kony.flex.DP);
    var guruOpen = new kony.ui.Label({
        "id": "guruOpen",
        "isVisible": true,
        "left": "42%",
        "skin": "CopyslLabel0372edb8e723b47",
        "text": "-",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "10dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var guruPending = new kony.ui.Label({
        "id": "guruPending",
        "isVisible": true,
        "left": "62%",
        "skin": "CopyslLabel0759d8f3135f84d",
        "text": "-",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "10dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var guruTotal = new kony.ui.Label({
        "id": "guruTotal",
        "isVisible": true,
        "left": "85%",
        "skin": "CopyslLabel0372edb8e723b47",
        "text": "-",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "10dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var CopyLabel0fade3dd5d3f040 = new kony.ui.Label({
        "id": "CopyLabel0fade3dd5d3f040",
        "isVisible": true,
        "left": "2%",
        "skin": "CopyslLabel0794ade92fb164a",
        "text": "Guru",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "5dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    guruFlex.add(guruOpen, guruPending, guruTotal, CopyLabel0fade3dd5d3f040);
    var manishFlex = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "5%",
        "id": "manishFlex",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "skin": "CopyslFbox002e351fe934045",
        "top": "45%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    manishFlex.setDefaultUnit(kony.flex.DP);
    var manishOpen = new kony.ui.Label({
        "id": "manishOpen",
        "isVisible": true,
        "left": "42%",
        "skin": "CopyslLabel0372edb8e723b47",
        "text": "0",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "10dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var manishPending = new kony.ui.Label({
        "id": "manishPending",
        "isVisible": true,
        "left": "62%",
        "skin": "CopyslLabel0759d8f3135f84d",
        "text": "0",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "10dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var manishTotal = new kony.ui.Label({
        "id": "manishTotal",
        "isVisible": true,
        "left": "85%",
        "skin": "CopyslLabel0372edb8e723b47",
        "text": "0",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "10dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var CopyLabel0d29c4fd52e3647 = new kony.ui.Label({
        "id": "CopyLabel0d29c4fd52e3647",
        "isVisible": true,
        "left": "2%",
        "skin": "CopyslLabel0794ade92fb164a",
        "text": "Madhuri",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "5dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    manishFlex.add(manishOpen, manishPending, manishTotal, CopyLabel0d29c4fd52e3647);
    var nagarajuFlex = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "5%",
        "id": "nagarajuFlex",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "skin": "CopyslFbox06e29e5ebb47244",
        "top": "50%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    nagarajuFlex.setDefaultUnit(kony.flex.DP);
    var nagarajuOpen = new kony.ui.Label({
        "id": "nagarajuOpen",
        "isVisible": true,
        "left": "42%",
        "skin": "CopyslLabel0372edb8e723b47",
        "text": "-",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "10dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var nagarajuPending = new kony.ui.Label({
        "id": "nagarajuPending",
        "isVisible": true,
        "left": "62%",
        "skin": "CopyslLabel0759d8f3135f84d",
        "text": "-",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "10dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var nagarajuTotal = new kony.ui.Label({
        "id": "nagarajuTotal",
        "isVisible": true,
        "left": "85%",
        "skin": "CopyslLabel0372edb8e723b47",
        "text": "-",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "10dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var CopyLabel033c70c1c80734d = new kony.ui.Label({
        "id": "CopyLabel033c70c1c80734d",
        "isVisible": true,
        "left": "2%",
        "skin": "CopyslLabel0794ade92fb164a",
        "text": "Nagaraju",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "5dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    nagarajuFlex.add(nagarajuOpen, nagarajuPending, nagarajuTotal, CopyLabel033c70c1c80734d);
    var naveenFlex = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "5%",
        "id": "naveenFlex",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "skin": "CopyslFbox044baaf6d3c854d",
        "top": "55%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    naveenFlex.setDefaultUnit(kony.flex.DP);
    var naveenOpen = new kony.ui.Label({
        "id": "naveenOpen",
        "isVisible": true,
        "left": "42%",
        "skin": "CopyslLabel0372edb8e723b47",
        "text": "-",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "10dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var naveenPending = new kony.ui.Label({
        "id": "naveenPending",
        "isVisible": true,
        "left": "62%",
        "skin": "CopyslLabel0759d8f3135f84d",
        "text": "-",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "10dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var naveenTotal = new kony.ui.Label({
        "id": "naveenTotal",
        "isVisible": true,
        "left": "85%",
        "skin": "CopyslLabel0372edb8e723b47",
        "text": "-",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "10dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var CopyLabel0fc70c27f077644 = new kony.ui.Label({
        "id": "CopyLabel0fc70c27f077644",
        "isVisible": true,
        "left": "2%",
        "skin": "CopyslLabel0794ade92fb164a",
        "text": "Naveen",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "5dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    naveenFlex.add(naveenOpen, naveenPending, naveenTotal, CopyLabel0fc70c27f077644);
    var radhikaFlex = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "5%",
        "id": "radhikaFlex",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "skin": "CopyslFbox09763de6a5b5a46",
        "top": "60%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    radhikaFlex.setDefaultUnit(kony.flex.DP);
    var radhikaOpen = new kony.ui.Label({
        "id": "radhikaOpen",
        "isVisible": true,
        "left": "42%",
        "skin": "CopyslLabel0372edb8e723b47",
        "text": "-",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "10dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var radhikaPending = new kony.ui.Label({
        "id": "radhikaPending",
        "isVisible": true,
        "left": "62%",
        "skin": "CopyslLabel0759d8f3135f84d",
        "text": "-",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "10dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var radhikaTotal = new kony.ui.Label({
        "id": "radhikaTotal",
        "isVisible": true,
        "left": "85%",
        "skin": "CopyslLabel0372edb8e723b47",
        "text": "-",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "10dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var CopyLabel0c23c1f665bc34d = new kony.ui.Label({
        "id": "CopyLabel0c23c1f665bc34d",
        "isVisible": true,
        "left": "2%",
        "skin": "CopyslLabel0794ade92fb164a",
        "text": "Radhika",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "5dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    radhikaFlex.add(radhikaOpen, radhikaPending, radhikaTotal, CopyLabel0c23c1f665bc34d);
    var rashmiMFlex = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "5%",
        "id": "rashmiMFlex",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "skin": "CopyslFbox0f9cdd479ba1e4c",
        "top": "65%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    rashmiMFlex.setDefaultUnit(kony.flex.DP);
    var rashmiMOpen = new kony.ui.Label({
        "id": "rashmiMOpen",
        "isVisible": true,
        "left": "42%",
        "skin": "CopyslLabel0372edb8e723b47",
        "text": "-",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "10dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var rashmiMPending = new kony.ui.Label({
        "id": "rashmiMPending",
        "isVisible": true,
        "left": "62%",
        "skin": "CopyslLabel0759d8f3135f84d",
        "text": "-",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "10dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var rashmiMTotal = new kony.ui.Label({
        "id": "rashmiMTotal",
        "isVisible": true,
        "left": "85%",
        "skin": "CopyslLabel0372edb8e723b47",
        "text": "-",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "10dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var CopyLabel005660c7e987a49 = new kony.ui.Label({
        "id": "CopyLabel005660c7e987a49",
        "isVisible": true,
        "left": "2%",
        "skin": "CopyslLabel0794ade92fb164a",
        "text": "Rashmi",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "5dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    rashmiMFlex.add(rashmiMOpen, rashmiMPending, rashmiMTotal, CopyLabel005660c7e987a49);
    var raviPadFlex = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "5%",
        "id": "raviPadFlex",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "skin": "CopyslFbox00e4f2d74d4d441",
        "top": "70%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    raviPadFlex.setDefaultUnit(kony.flex.DP);
    var raviPadOpen = new kony.ui.Label({
        "id": "raviPadOpen",
        "isVisible": true,
        "left": "42%",
        "skin": "CopyslLabel0372edb8e723b47",
        "text": "-",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "10dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var raviPadPending = new kony.ui.Label({
        "id": "raviPadPending",
        "isVisible": true,
        "left": "62%",
        "skin": "CopyslLabel0759d8f3135f84d",
        "text": "-",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "10dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var raviPadTotal = new kony.ui.Label({
        "id": "raviPadTotal",
        "isVisible": true,
        "left": "85%",
        "skin": "CopyslLabel0372edb8e723b47",
        "text": "-",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "10dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var CopyLabel036b2e34c105748 = new kony.ui.Label({
        "id": "CopyLabel036b2e34c105748",
        "isVisible": true,
        "left": "2%",
        "skin": "CopyslLabel0794ade92fb164a",
        "text": "Ravi Padigela",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "5dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    raviPadFlex.add(raviPadOpen, raviPadPending, raviPadTotal, CopyLabel036b2e34c105748);
    var FlexContainer039988780bbb143 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "7%",
        "id": "FlexContainer039988780bbb143",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0dp",
        "skin": "CopyslFbox04313620086a946",
        "top": "10%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    FlexContainer039988780bbb143.setDefaultUnit(kony.flex.DP);
    var Label07cb3e6aadc9340 = new kony.ui.Label({
        "id": "Label07cb3e6aadc9340",
        "isVisible": true,
        "left": "2%",
        "skin": "CopyslLabel0fe937e20284b43",
        "text": "MADP Status",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "5%",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var CopyLabel04c7a2a04f37044 = new kony.ui.Label({
        "id": "CopyLabel04c7a2a04f37044",
        "isVisible": true,
        "right": "2%",
        "skin": "CopyslLabel0fe937e20284b43",
        "text": "Page 1/2",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "5%",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    FlexContainer039988780bbb143.add(Label07cb3e6aadc9340, CopyLabel04c7a2a04f37044);
    var km22033743e63440ea7d5b035f8f9b33f = new kony.ui.FlexContainer({
        "isMaster": true,
        "height": "10%",
        "id": "masterFlexHeader",
        "left": "0dp",
        "top": "0dp",
        "width": "100%",
        "zIndex": 1,
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "skin": "slFbox"
    }, {}, {});
    km22033743e63440ea7d5b035f8f9b33f.setDefaultUnit(kony.flex.DP);
    var kmb1b6fd3da6b4a33a8e604d7759f531f = new kony.ui.FlexContainer({
        "height": "100%",
        "id": "FlexContainer06c89085ee5754a",
        "left": "0dp",
        "top": "0dp",
        "width": "100%",
        "zIndex": 1,
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "skin": "CopyslFbox0b823aeeea1ee45"
    }, {}, {});
    kmb1b6fd3da6b4a33a8e604d7759f531f.setDefaultUnit(kony.flex.DP);
    var kmb82d96538bb49868014a9246461b6a2 = new kony.ui.Label({
        "id": "Label0bb5fed64490342",
        "left": "20%",
        "text": "CSE Ticket Status",
        "top": "25%",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1,
        "isVisible": true,
        "skin": "CopyslLabel058b3abcc5c3946",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        }
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var kmabccea991714f9eb7a8ac06bc4290c3 = new kony.ui.Image2({
        "height": "20dp",
        "id": "Image0ee368462a3764e",
        "left": 0,
        "right": 0,
        "src": "kony_logo2x.png",
        "top": "4dp",
        "width": "60dp",
        "zIndex": 1,
        "isVisible": true,
        "skin": "slImage"
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    kmb1b6fd3da6b4a33a8e604d7759f531f.add(kmb82d96538bb49868014a9246461b6a2, kmabccea991714f9eb7a8ac06bc4290c3);
    km22033743e63440ea7d5b035f8f9b33f.add(kmb1b6fd3da6b4a33a8e604d7759f531f);
    frmAgentData.add(Label04e655f60c7854d, timeStampLabel, refreshButton, insideFlex, footerFlex, jabiFlex, anuragFlex, baluFlex, guruFlex, manishFlex, nagarajuFlex, naveenFlex, radhikaFlex, rashmiMFlex, raviPadFlex, FlexContainer039988780bbb143, km22033743e63440ea7d5b035f8f9b33f);
};

function frmAgentDataGlobals() {
    frmAgentData = new kony.ui.Form2({
        "addWidgets": addWidgetsfrmAgentData,
        "enabledForIdleTimeout": false,
        "id": "frmAgentData",
        "init": AS_Form_29f2a1a81eea44eb9f81fa1f2be301a9,
        "layoutType": kony.flex.FREE_FORM,
        "needAppMenu": false,
        "preShow": AS_Form_3fe568c3ee9d44a0ab7a4326b3c822c2,
        "skin": "CopyslForm028c735bf23e94b"
    }, {
        "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
        "layoutType": kony.flex.FREE_FORM,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "footerOverlap": false,
        "headerOverlap": false,
        "inTransitionConfig": {
            "formAnimation": 4
        },
        "menuPosition": constants.FORM_MENU_POSITION_AFTER_APPMENU,
        "outTransitionConfig": {
            "transitionDirection": "fromRight",
            "transitionDuration": 0.3,
            "transitionEffect": "transitionCloth"
        },
        "retainScrollPosition": false,
        "titleBar": true,
        "titleBarSkin": "slTitleBar",
        "windowSoftInputMode": constants.FORM_ADJUST_PAN
    });
};