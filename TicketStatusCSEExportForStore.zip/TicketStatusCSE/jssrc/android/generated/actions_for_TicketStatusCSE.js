//actions.js file 
function AS_AppEvents_c4b65b216ab1466584bfad7936dfdec2(eventobject) {
    callbackAndroidOriphoneSetCallbacks();
}

function AS_Button_14bebb84f41148a382ea51158141796a(eventobject) {
    frmAgentData.show();
}

function AS_Button_5fdb7f27277e4602bbcc463138d43542(eventobject) {
    frmAgentData2.show();
}

function AS_Button_8279e0c1736f48678e7c908a066b62be(eventobject) {
    frmAgentData.show();
}

function AS_Button_8337ff0ffdbc4b9a8ea9327115da8dfa(eventobject) {
    frmHomePage.show();
}

function AS_Button_91ee0b7311e249bdaeddfc43696a3fd5(eventobject) {
    return frmAgentDataMain2.call(this);
}

function AS_Button_adf0c600183b44d7830f97e24c259c88(eventobject) {
    function MOVE_ACTION____f5e3c9583b7f40b6bb75d68e2921e765_Callback() {
        logout.call(this);
    }
    frmHomePage.flxMoveForNotice.animate(kony.ui.createAnimation({
        "100": {
            "left": "-51%",
            "stepConfig": {
                "timingFunction": kony.anim.EASE
            },
            "rectified": true
        }
    }), {
        "iterationCount": 1,
        "fillMode": kony.anim.FILL_MODE_FORWARDS,
        "duration": 0.025
    }, {
        "animationEnd": MOVE_ACTION____f5e3c9583b7f40b6bb75d68e2921e765_Callback
    });
}

function AS_Button_b5722e56dc2447f49c4c32d82d0baad5(eventobject) {
    frmHomePage.show();
}

function AS_Button_b71574557b30468bad916b70eded4d3d(eventobject) {
    return frmAgentDataMain.call(this);
}

function AS_Button_bf68b4c860a44d02ab328f0536c10a37(eventobject) {
    return ClearButtonForNotificationOnActionWithOutNetCheck.call(this);
}

function AS_Button_c68c0e39b5e34235bdcfbe5960fa33ce(eventobject) {
    frmHomePage.show();
}

function AS_Button_cbbe85f0f6aa4d63969430c5bf5ba2fc(eventobject) {
    return NetWorkCheck.call(this);
}

function AS_Button_d2b33bfc70f840f582464e250b34afee(eventobject) {
    frmAgentData.show();
}

function AS_Button_e5d9820e69f94c29bed447ffc7781f2d(eventobject) {
    frmAgentDataMF.show();
}

function AS_Button_f50c8ada6f4f4e2d88b79e8cce44d283(eventobject) {
    return callbackAndroidOriphoneRegister.call(this);
}

function AS_Button_fb5cbaa4682b4a4ab2bad282ae7e4a98(eventobject) {
    return frmAgentDataMainMF.call(this);
}

function AS_Form_1fc77aa7fdb4406b9b2f29451eb0e1b8(eventobject) {
    return LMain.call(this);
}

function AS_Form_29f2a1a81eea44eb9f81fa1f2be301a9(eventobject) {}

function AS_Form_3fe568c3ee9d44a0ab7a4326b3c822c2(eventobject) {
    return frmAgentDataMain.call(this);
}

function AS_Form_41f5db727aaf496bb0490356d5a0ba90(eventobject) {
    return frmAgentDataMain2.call(this);
}

function AS_Form_5e6efc482f3b42a1879b836727c41f94(eventobject) {}

function AS_Form_839b78c5a3cd4ae0b317ef2a585fd171(eventobject) {}

function AS_Form_a5f07e8a2f264938802afe5dd765f4dc(eventobject) {
    LMain.call(this);
    RememberMe.call(this);
}

function AS_Form_aab47ea43ada4b2f9e49a5bc281d6443(eventobject) {
    frmHomePage.imgOut.setVisibility(true);
    if (kony.store.getItem("pushList") != null) {
        var pushString = kony.store.getItem("pushList");
        pushString = "{\"dataSet\":[" + pushString + "]}";
        var test = JSON.parse(pushString);
        var frontNoteSeg = {
            dataSet: []
        };
        frmHomePage.segPush.widgetDataMap = {
            lblSegHeadTitle: "title",
            lblSegContent: "content"
        };
        frmHomePage.segPush.setData(test.dataSet);
    }
}

function AS_Form_b5c76f0fb68a49caa5d7f202d45e92b7(eventobject) {
    return ValidateUser.call(this);
}

function AS_Form_e4cb4ca87edd4ed48153bced716b1dab(eventobject) {
    return frmAgentDataMainMF.call(this);
}

function AS_Form_eb7c4707d2c2456e8faeae174b299189(eventobject) {}

function AS_Form_facd1bcc86304ead900e90e4590bcbfc(eventobject) {
    minitiateMF.call(this);
    frmLogin.FlexContainer0j95a6b1c5e2749.txtUser.left = "34%";
    frmLogin.FlexContainer0j95a6b1c5e2749.txtUser.top = "18%";
    frmLogin.FlexContainer0j95a6b1c5e2749.txtPassWord.left = "34%";
    frmLogin.FlexContainer0j95a6b1c5e2749.txtPassWord.top = "44%";
    /*frmLogin.FlexContainer0j95a6b1c5e2749.Label0a0ea6f29991248.left="2";
    frmLogin.FlexContainer0j95a6b1c5e2749.Label0a0ea6f29991248.top="45.5";
    frmLogin.FlexContainer0j95a6b1c5e2749.Label0a0ea6f29991248.width="30";
    frmLogin.FlexContainer0j95a6b1c5e2749.Label0a0ea6f29991248.height="10";
    frmLogin.FlexContainer0j95a6b1c5e2749.Label0a0ea6f29991248.z
    */
    frmLogin.forceLayout();
    frmLogin.FlexContainer0j95a6b1c5e2749.forceLayout();
}

function AS_Image_17bde5db74a345aba50c04124d88691e(eventobject, x, y) {}

function AS_Image_6732d9f3e38948a08a690f6e8c8fd017(eventobject, x, y) {}

function AS_Image_7bdd3d10dab44e329305841f0f8ebc95(eventobject, x, y) {}

function AS_Image_a401611f21e5484984e7a64868ed9bd7(eventobject, x, y) {
    deregister.call(this);
    ClearButtonForNotificationOnAction.call(this);
}

function AS_Image_b7a3f142d52f44a6bd3cf8327ceb9a60(eventobject, x, y) {
    function MOVE_ACTION____a7202bacad4b4a0d9d989aad7ca2164d_Callback() {}
    frmHomePage.flxMoveForNotice.animate(kony.ui.createAnimation({
        "100": {
            "left": "0%",
            "stepConfig": {
                "timingFunction": kony.anim.EASE
            }
        }
    }), {
        "delay": 0,
        "iterationCount": 1,
        "fillMode": kony.anim.FILL_MODE_FORWARDS,
        "duration": 0.25
    }, {
        "animationEnd": MOVE_ACTION____a7202bacad4b4a0d9d989aad7ca2164d_Callback
    });
    frmHomePage.imgOut.setVisibility(false);
    if (kony.store.getItem("isFirstTime2") == null) {
        frmHomePage.flxPush.setVisibility(true);
        //frmHomePage.flxNotePrint.setVisibility(false);
        frmHomePage.segPush.setVisibility(false);
        frmHomePage.imgUnsubscribe.setVisibility(false);
        frmHomePage.forceLayout();
    } else {
        frmHomePage.flxPush.setVisibility(false);
        //frmHomePage.flxNotePrint.setVisibility(true);
        frmHomePage.segPush.setVisibility(true);
        frmHomePage.imgUnsubscribe.setVisibility(true);
    }
    setAnimationForMenu.call(this);
    ValidateUser.call(this);
}

function AS_Image_b84f66774e6646d493da1a24e1ac2a9c(eventobject, imagesrc, issuccess) {}

function AS_Image_be4661b6478c4a54a8822b3d9359eb13(eventobject, x, y) {
    return callbackAndroidOriphoneRegister.call(this);
}

function AS_Image_c9e76e3bb39340b5b1c6548d33cfc0a4(eventobject, x, y) {
    function MOVE_ACTION____b940dd9e2de548a5b3b529aa4fdc88a9_Callback() {
        frmHomePage.imgOut.setVisibility(true);
    }
    frmHomePage.flxMoveForNotice.animate(kony.ui.createAnimation({
        "100": {
            "left": "-51%",
            "stepConfig": {
                "timingFunction": kony.anim.EASE
            }
        }
    }), {
        "delay": 0,
        "iterationCount": 1,
        "fillMode": kony.anim.FILL_MODE_FORWARDS,
        "duration": 0.25
    }, {
        "animationEnd": MOVE_ACTION____b940dd9e2de548a5b3b529aa4fdc88a9_Callback
    });
}

function AS_Label_14ae504eec074a288ef4cd29e6aaa378(eventobject, x, y) {
    kony.application.openURL("https://konysolutions.zendesk.com/agent/filters/39040784");
}

function AS_Label_31f2dfec7dc648b3a0592e978e5fccc5(eventobject, x, y) {
    kony.application.openURL("https://konysolutions.zendesk.com/agent/filters/39040784");
}