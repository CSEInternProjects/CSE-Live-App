function addWidgetsfrmAgentData2() {
    frmAgentData2.setDefaultUnit(kony.flex.DP);
    var Label04e655f60c7854d = new kony.ui.Label({
        "id": "Label04e655f60c7854d",
        "isVisible": true,
        "left": "50dp",
        "skin": "CopyslLabel0497d03338d8546",
        "text": "last refreshed at ",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "81%",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var timeStampLabel = new kony.ui.Label({
        "id": "timeStampLabel",
        "isVisible": true,
        "left": "164dp",
        "skin": "CopyslLabel07869ff3974a547",
        "text": "timestamp",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "81%",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var refreshButton = new kony.ui.Image2({
        "height": "33dp",
        "id": "refreshButton",
        "isVisible": true,
        "left": "8dp",
        "onTouchStart": AS_Image_7bdd3d10dab44e329305841f0f8ebc95,
        "skin": "slImage",
        "src": "refreshbutton.png",
        "top": "80%",
        "width": "37dp",
        "zIndex": 1
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var insideFlex = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "8%",
        "id": "insideFlex",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0dp",
        "skin": "CopyslFbox0b3627984c31943",
        "top": "17%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    insideFlex.setDefaultUnit(kony.flex.DP);
    var Label0b657f10096734a = new kony.ui.Label({
        "id": "Label0b657f10096734a",
        "isVisible": true,
        "left": "2%",
        "skin": "CopyslLabel0908910268e204d",
        "text": "Engineer",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "40%",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var Label001bc1f55ec6744 = new kony.ui.Label({
        "id": "Label001bc1f55ec6744",
        "isVisible": true,
        "left": "40%",
        "skin": "CopyslLabel0b9cb57ed707d46",
        "text": "Open",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "40%",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var Label00794b501e82947 = new kony.ui.Label({
        "id": "Label00794b501e82947",
        "isVisible": true,
        "left": "60%",
        "skin": "CopyslLabel0c925fd360d244e",
        "text": "Pending",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "40%",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var CopyLabel08f5dc29d0fa04c = new kony.ui.Label({
        "id": "CopyLabel08f5dc29d0fa04c",
        "isVisible": true,
        "left": "85%",
        "skin": "CopyslLabel0c925fd360d244e",
        "text": "Total",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "40%",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    insideFlex.add(Label0b657f10096734a, Label001bc1f55ec6744, Label00794b501e82947, CopyLabel08f5dc29d0fa04c);
    var footerFlex = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "bottom": "0%",
        "clipBounds": true,
        "height": "7.40%",
        "id": "footerFlex",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0dp",
        "skin": "CopyslFbox0d8613b7525414d",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    footerFlex.setDefaultUnit(kony.flex.DP);
    var btnHome = new kony.ui.Button({
        "height": "60%",
        "id": "btnHome",
        "isVisible": true,
        "left": "1%",
        "onClick": AS_Button_c68c0e39b5e34235bdcfbe5960fa33ce,
        "skin": "CopyslButtonGlossBlue00b7c3a62349a4d",
        "text": "Home",
        "top": "25%",
        "width": "30%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var btnNextMADP = new kony.ui.Button({
        "height": "60%",
        "id": "btnNextMADP",
        "isVisible": true,
        "onClick": AS_Button_14bebb84f41148a382ea51158141796a,
        "right": "1%",
        "skin": "CopyslButtonGlossBlue00b7c3a62349a4d",
        "text": "Back",
        "top": "25%",
        "width": "30%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var refreshPage = new kony.ui.Button({
        "height": "60%",
        "id": "refreshPage",
        "isVisible": true,
        "onClick": AS_Button_91ee0b7311e249bdaeddfc43696a3fd5,
        "right": "35.67%",
        "skin": "CopyslButtonGlossBlue0bc052b1b7c8b45",
        "text": "Refresh",
        "top": "25%",
        "width": "30%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    footerFlex.add(btnHome, btnNextMADP, refreshPage);
    var raviPyFlex = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "5%",
        "id": "raviPyFlex",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "skin": "CopyslFbox0cfaa4a8780ee48",
        "top": "25%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    raviPyFlex.setDefaultUnit(kony.flex.DP);
    var raviPyOpen = new kony.ui.Label({
        "id": "raviPyOpen",
        "isVisible": true,
        "left": "42%",
        "skin": "CopyslLabel0372edb8e723b47",
        "text": "-",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "10dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var raviPyPending = new kony.ui.Label({
        "id": "raviPyPending",
        "isVisible": true,
        "left": "62%",
        "skin": "CopyslLabel0759d8f3135f84d",
        "text": "-",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "10dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var raviPyTotal = new kony.ui.Label({
        "id": "raviPyTotal",
        "isVisible": true,
        "left": "85%",
        "skin": "CopyslLabel0372edb8e723b47",
        "text": "-",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "10dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var Label0d21985708a7a43 = new kony.ui.Label({
        "id": "Label0d21985708a7a43",
        "isVisible": true,
        "left": "2%",
        "skin": "CopyslLabel0794ade92fb164a",
        "text": "Ravi Pyreddy",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "7dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    raviPyFlex.add(raviPyOpen, raviPyPending, raviPyTotal, Label0d21985708a7a43);
    var raviBeFlex = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "5%",
        "id": "raviBeFlex",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "skin": "CopyslFbox0cbb4b8dfaebf47",
        "top": "30%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    raviBeFlex.setDefaultUnit(kony.flex.DP);
    var raviBeOpen = new kony.ui.Label({
        "id": "raviBeOpen",
        "isVisible": true,
        "left": "42%",
        "skin": "CopyslLabel0372edb8e723b47",
        "text": "-",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "10dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var raviBePending = new kony.ui.Label({
        "id": "raviBePending",
        "isVisible": true,
        "left": "62%",
        "skin": "CopyslLabel0759d8f3135f84d",
        "text": "-",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "10dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var raviBeTotal = new kony.ui.Label({
        "id": "raviBeTotal",
        "isVisible": true,
        "left": "85%",
        "skin": "CopyslLabel0372edb8e723b47",
        "text": "-",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "10dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var CopyLabel0a67b3065ba0a45 = new kony.ui.Label({
        "id": "CopyLabel0a67b3065ba0a45",
        "isVisible": true,
        "left": "2%",
        "skin": "CopyslLabel0794ade92fb164a",
        "text": "Ravinder B",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "6dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    raviBeFlex.add(raviBeOpen, raviBePending, raviBeTotal, CopyLabel0a67b3065ba0a45);
    var rojalinFlex = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "5%",
        "id": "rojalinFlex",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "skin": "CopyslFbox0fc533fa22c9b4e",
        "top": "35%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    rojalinFlex.setDefaultUnit(kony.flex.DP);
    var rojalinOpen = new kony.ui.Label({
        "id": "rojalinOpen",
        "isVisible": true,
        "left": "42%",
        "skin": "CopyslLabel0372edb8e723b47",
        "text": "-",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "10dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var rojalinPending = new kony.ui.Label({
        "id": "rojalinPending",
        "isVisible": true,
        "left": "62%",
        "skin": "CopyslLabel0759d8f3135f84d",
        "text": "-",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "10dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var rojalinTotal = new kony.ui.Label({
        "id": "rojalinTotal",
        "isVisible": true,
        "left": "85%",
        "skin": "CopyslLabel0372edb8e723b47",
        "text": "-",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "10dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var CopyLabel090ec2d0f671b4f = new kony.ui.Label({
        "id": "CopyLabel090ec2d0f671b4f",
        "isVisible": true,
        "left": "2%",
        "skin": "CopyslLabel0794ade92fb164a",
        "text": "Rojalin",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "5dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    rojalinFlex.add(rojalinOpen, rojalinPending, rojalinTotal, CopyLabel090ec2d0f671b4f);
    var santoshNFlex = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "5%",
        "id": "santoshNFlex",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "skin": "CopyslFbox0cc075cd3378448",
        "top": "40%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    santoshNFlex.setDefaultUnit(kony.flex.DP);
    var santoshNOpen = new kony.ui.Label({
        "id": "santoshNOpen",
        "isVisible": true,
        "left": "42%",
        "skin": "CopyslLabel0372edb8e723b47",
        "text": "-",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "10dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var santoshNPending = new kony.ui.Label({
        "id": "santoshNPending",
        "isVisible": true,
        "left": "62%",
        "skin": "CopyslLabel0759d8f3135f84d",
        "text": "-",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "10dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var santoshNTotal = new kony.ui.Label({
        "id": "santoshNTotal",
        "isVisible": true,
        "left": "85%",
        "skin": "CopyslLabel0372edb8e723b47",
        "text": "-",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "10dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var CopyLabel0fade3dd5d3f040 = new kony.ui.Label({
        "id": "CopyLabel0fade3dd5d3f040",
        "isVisible": true,
        "left": "2%",
        "skin": "CopyslLabel0794ade92fb164a",
        "text": "Santhosh N",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "5dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    santoshNFlex.add(santoshNOpen, santoshNPending, santoshNTotal, CopyLabel0fade3dd5d3f040);
    var sirishaFlex = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "5%",
        "id": "sirishaFlex",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "skin": "CopyslFbox002e351fe934045",
        "top": "45%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    sirishaFlex.setDefaultUnit(kony.flex.DP);
    var sirishaOpen = new kony.ui.Label({
        "id": "sirishaOpen",
        "isVisible": true,
        "left": "42%",
        "skin": "CopyslLabel0372edb8e723b47",
        "text": "-",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "10dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var sirishaPending = new kony.ui.Label({
        "id": "sirishaPending",
        "isVisible": true,
        "left": "62%",
        "skin": "CopyslLabel0759d8f3135f84d",
        "text": "-",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "10dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var sirishaTotal = new kony.ui.Label({
        "id": "sirishaTotal",
        "isVisible": true,
        "left": "85%",
        "skin": "CopyslLabel0372edb8e723b47",
        "text": "-",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "10dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var CopyLabel0d29c4fd52e3647 = new kony.ui.Label({
        "id": "CopyLabel0d29c4fd52e3647",
        "isVisible": true,
        "left": "2%",
        "skin": "CopyslLabel0794ade92fb164a",
        "text": "Sirisha",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "5dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    sirishaFlex.add(sirishaOpen, sirishaPending, sirishaTotal, CopyLabel0d29c4fd52e3647);
    var johnvinodhFlex = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "5%",
        "id": "johnvinodhFlex",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "skin": "CopyslFbox06e29e5ebb47244",
        "top": "50%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    johnvinodhFlex.setDefaultUnit(kony.flex.DP);
    var johnvinodhOpen = new kony.ui.Label({
        "id": "johnvinodhOpen",
        "isVisible": true,
        "left": "42%",
        "skin": "CopyslLabel0372edb8e723b47",
        "text": "-",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "10dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var johnvinodhPending = new kony.ui.Label({
        "id": "johnvinodhPending",
        "isVisible": true,
        "left": "62%",
        "skin": "CopyslLabel0759d8f3135f84d",
        "text": "-",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "10dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var johnvinodhTotal = new kony.ui.Label({
        "id": "johnvinodhTotal",
        "isVisible": true,
        "left": "85%",
        "skin": "CopyslLabel0372edb8e723b47",
        "text": "-",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "10dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var CopyLabel033c70c1c80734d = new kony.ui.Label({
        "id": "CopyLabel033c70c1c80734d",
        "isVisible": true,
        "left": "2%",
        "skin": "CopyslLabel0794ade92fb164a",
        "text": "Johnvinodh",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "5dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    johnvinodhFlex.add(johnvinodhOpen, johnvinodhPending, johnvinodhTotal, CopyLabel033c70c1c80734d);
    var venkatTFlex = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "30dp",
        "id": "venkatTFlex",
        "isVisible": false,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "skin": "CopyslFbox044baaf6d3c854d",
        "top": "55%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    venkatTFlex.setDefaultUnit(kony.flex.DP);
    var venkatTOpen = new kony.ui.Label({
        "id": "venkatTOpen",
        "isVisible": true,
        "left": "42%",
        "skin": "CopyslLabel0372edb8e723b47",
        "text": "test",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "10dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var venkatTPending = new kony.ui.Label({
        "id": "venkatTPending",
        "isVisible": true,
        "left": "62%",
        "skin": "CopyslLabel0759d8f3135f84d",
        "text": "test",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "10dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var venkatTTotal = new kony.ui.Label({
        "id": "venkatTTotal",
        "isVisible": true,
        "left": "85%",
        "skin": "CopyslLabel0372edb8e723b47",
        "text": "test",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "10dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var CopyLabel0fc70c27f077644 = new kony.ui.Label({
        "id": "CopyLabel0fc70c27f077644",
        "isVisible": true,
        "left": "2%",
        "skin": "CopyslLabel0794ade92fb164a",
        "text": "Venkat T",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "5dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    venkatTFlex.add(venkatTOpen, venkatTPending, venkatTTotal, CopyLabel0fc70c27f077644);
    var FlexContainer039988780bbb143 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "7%",
        "id": "FlexContainer039988780bbb143",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0dp",
        "skin": "CopyslFbox04313620086a946",
        "top": "10%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    FlexContainer039988780bbb143.setDefaultUnit(kony.flex.DP);
    var Label07cb3e6aadc9340 = new kony.ui.Label({
        "id": "Label07cb3e6aadc9340",
        "isVisible": true,
        "left": "2%",
        "skin": "CopyslLabel0fe937e20284b43",
        "text": "MADP Status",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "5%",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var CopyLabel04c7a2a04f37044 = new kony.ui.Label({
        "id": "CopyLabel04c7a2a04f37044",
        "isVisible": true,
        "right": "2%",
        "skin": "CopyslLabel0fe937e20284b43",
        "text": "Page 2/2",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "5%",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    FlexContainer039988780bbb143.add(Label07cb3e6aadc9340, CopyLabel04c7a2a04f37044);
    var km3fd35ee05da4dccaa8d55a902c9680d = new kony.ui.FlexContainer({
        "isMaster": true,
        "height": "10%",
        "id": "masterFlexHeader",
        "left": "0dp",
        "top": "0dp",
        "width": "100%",
        "zIndex": 1,
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "skin": "slFbox"
    }, {}, {});
    km3fd35ee05da4dccaa8d55a902c9680d.setDefaultUnit(kony.flex.DP);
    var km113bdb84fc2410380f0d620ca5aacaf = new kony.ui.FlexContainer({
        "height": "100%",
        "id": "FlexContainer06c89085ee5754a",
        "left": "0dp",
        "top": "0dp",
        "width": "100%",
        "zIndex": 1,
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "skin": "CopyslFbox0b823aeeea1ee45"
    }, {}, {});
    km113bdb84fc2410380f0d620ca5aacaf.setDefaultUnit(kony.flex.DP);
    var kmb2ecc77540048009a60fe1b0df16bb4 = new kony.ui.Label({
        "id": "Label0bb5fed64490342",
        "left": "20%",
        "text": "CSE Ticket Status",
        "top": "25%",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1,
        "isVisible": true,
        "skin": "CopyslLabel058b3abcc5c3946",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        }
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var km66635a482a84ce6a89a5c5bf486dab3 = new kony.ui.Image2({
        "height": "20dp",
        "id": "Image0ee368462a3764e",
        "left": 0,
        "right": 0,
        "src": "kony_logo2x.png",
        "top": "4dp",
        "width": "60dp",
        "zIndex": 1,
        "isVisible": true,
        "skin": "slImage"
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    km113bdb84fc2410380f0d620ca5aacaf.add(kmb2ecc77540048009a60fe1b0df16bb4, km66635a482a84ce6a89a5c5bf486dab3);
    km3fd35ee05da4dccaa8d55a902c9680d.add(km113bdb84fc2410380f0d620ca5aacaf);
    frmAgentData2.add(Label04e655f60c7854d, timeStampLabel, refreshButton, insideFlex, footerFlex, raviPyFlex, raviBeFlex, rojalinFlex, santoshNFlex, sirishaFlex, johnvinodhFlex, venkatTFlex, FlexContainer039988780bbb143, km3fd35ee05da4dccaa8d55a902c9680d);
};

function frmAgentData2Globals() {
    frmAgentData2 = new kony.ui.Form2({
        "addWidgets": addWidgetsfrmAgentData2,
        "enabledForIdleTimeout": false,
        "id": "frmAgentData2",
        "init": AS_Form_5e6efc482f3b42a1879b836727c41f94,
        "layoutType": kony.flex.FREE_FORM,
        "needAppMenu": false,
        "preShow": AS_Form_41f5db727aaf496bb0490356d5a0ba90,
        "skin": "CopyslForm028c735bf23e94b"
    }, {
        "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
        "layoutType": kony.flex.FREE_FORM,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "footerOverlap": false,
        "headerOverlap": false,
        "inTransitionConfig": {
            "formAnimation": 4
        },
        "menuPosition": constants.FORM_MENU_POSITION_AFTER_APPMENU,
        "outTransitionConfig": {
            "transitionDirection": "fromRight",
            "transitionDuration": 0.3,
            "transitionEffect": "transitionCloth"
        },
        "retainScrollPosition": false,
        "titleBar": true,
        "titleBarSkin": "slTitleBar",
        "windowSoftInputMode": constants.FORM_ADJUST_PAN
    });
};