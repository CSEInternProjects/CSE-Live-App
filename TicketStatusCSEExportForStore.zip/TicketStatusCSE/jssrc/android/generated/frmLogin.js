function addWidgetsfrmLogin() {
    frmLogin.setDefaultUnit(kony.flex.DP);
    var km383460fcf6c4c7da91803b0094ec2d9 = new kony.ui.FlexContainer({
        "isMaster": true,
        "height": "10%",
        "id": "masterFlexHeader",
        "left": "0%",
        "top": "0%",
        "width": "100%",
        "zIndex": 1,
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "skin": "slFbox"
    }, {}, {});
    km383460fcf6c4c7da91803b0094ec2d9.setDefaultUnit(kony.flex.DP);
    var kmc4c5da50b4a47a9a233b1798e9a73e8 = new kony.ui.FlexContainer({
        "height": "100%",
        "id": "FlexContainer06c89085ee5754a",
        "left": "0dp",
        "top": "0dp",
        "width": "100%",
        "zIndex": 1,
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "skin": "CopyslFbox0b823aeeea1ee45"
    }, {}, {});
    kmc4c5da50b4a47a9a233b1798e9a73e8.setDefaultUnit(kony.flex.DP);
    var kmd611116893f47ffa45c9219030571ce = new kony.ui.Label({
        "height": "64.86%",
        "id": "Label0bb5fed64490342",
        "left": "20%",
        "text": "CSE Ticket Status",
        "top": "30%",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1,
        "isVisible": true,
        "skin": "CopyslLabel058b3abcc5c3946",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        }
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var km496bd8d9f87417b83f5fb5fecc11ee9 = new kony.ui.Image2({
        "height": "43.24%",
        "id": "Image0ee368462a3764e",
        "left": "0%",
        "right": 0,
        "src": "kony_logo2x.png",
        "top": "4%",
        "width": "18.40%",
        "zIndex": 1,
        "isVisible": true,
        "skin": "slImage"
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    kmc4c5da50b4a47a9a233b1798e9a73e8.add(kmd611116893f47ffa45c9219030571ce, km496bd8d9f87417b83f5fb5fecc11ee9);
    km383460fcf6c4c7da91803b0094ec2d9.add(kmc4c5da50b4a47a9a233b1798e9a73e8);
    var Image0db8864c7c76043 = new kony.ui.Image2({
        "height": "11%",
        "id": "Image0db8864c7c76043",
        "isVisible": true,
        "left": "29.18%",
        "skin": "slImage",
        "src": "kony_logo2x.png",
        "top": "16.80%",
        "width": "45.37%",
        "zIndex": 1
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var FlexContainer0j95a6b1c5e2749 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "centerX": "50.00%",
        "centerY": "50.03%",
        "clipBounds": true,
        "height": "42.42%",
        "id": "FlexContainer0j95a6b1c5e2749",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "23%",
        "skin": "CopyslFbox0hf18d79cfc0241",
        "top": "180%",
        "width": "93.94%",
        "zIndex": 1
    }, {}, {});
    FlexContainer0j95a6b1c5e2749.setDefaultUnit(kony.flex.DP);
    var txtUser = new kony.ui.TextBox2({
        "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
        "height": "13.55%",
        "id": "txtUser",
        "isVisible": true,
        "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
        "placeholder": "employeeId",
        "secureTextEntry": false,
        "skin": "CopyslTextBox0hf714007e14f40",
        "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
        "width": "54.34%",
        "zIndex": 1
    }, {
        "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [3, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "autoFilter": false,
        "keyboardActionLabel": constants.TEXTBOX_KEYBOARD_LABEL_DEFAULT,
        "placeholderSkin": "CopyslTextBox0ibd78f7b0ecc42",
        "viewType": constants.TEXTBOX_VIEW_TYPE_DEFAULT
    });
    var txtPassWord = new kony.ui.TextBox2({
        "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
        "height": "13.53%",
        "id": "txtPassWord",
        "isVisible": true,
        "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
        "left": "34.07%",
        "placeholder": "*********",
        "secureTextEntry": true,
        "skin": "slTextBox",
        "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
        "top": "44.14%",
        "width": "54.21%",
        "zIndex": 1
    }, {
        "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [3, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "autoFilter": false,
        "keyboardActionLabel": constants.TEXTBOX_KEYBOARD_LABEL_DEFAULT,
        "viewType": constants.TEXTBOX_VIEW_TYPE_DEFAULT
    });
    var Button0gd0c3f980fd44e = new kony.ui.Button({
        "focusSkin": "slButtonGlossRed",
        "height": "12.77%",
        "id": "Button0gd0c3f980fd44e",
        "isVisible": true,
        "left": "52.06%",
        "onClick": AS_Button_cbbe85f0f6aa4d63969430c5bf5ba2fc,
        "skin": "CopyslButtonGlossBlue0i3267be8a3044b",
        "text": "Login",
        "top": "65.98%",
        "width": "35.46%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var Label0af02905b16f74e = new kony.ui.Label({
        "height": "12.77%",
        "id": "Label0af02905b16f74e",
        "isVisible": true,
        "left": "1.05%",
        "skin": "CopyslLabel0fd98cfcee0fd47",
        "text": "UserName",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "19.50%",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var Label0e85348f5833042 = new kony.ui.Label({
        "height": "10%",
        "id": "Label0e85348f5833042",
        "isVisible": true,
        "left": "2%",
        "skin": "CopyslLabel0d308588836a24d",
        "text": "PassWord",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "45.50%",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var checkboxForRememberMe = new kony.ui.CheckBoxGroup({
        "height": "12.20%",
        "id": "checkboxForRememberMe",
        "isVisible": true,
        "left": "2.9299999999999997%",
        "masterData": [
            ["true", "Remember me"]
        ],
        "skin": "CopyslCheckBoxGroup0j1f1a42c7d3642",
        "top": "65.86%",
        "width": "45.32%",
        "zIndex": 1
    }, {
        "itemOrientation": constants.CHECKBOX_ITEM_ORIENTATION_VERTICAL,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    FlexContainer0j95a6b1c5e2749.add(txtUser, txtPassWord, Button0gd0c3f980fd44e, Label0af02905b16f74e, Label0e85348f5833042, checkboxForRememberMe);
    frmLogin.add(km383460fcf6c4c7da91803b0094ec2d9, Image0db8864c7c76043, FlexContainer0j95a6b1c5e2749);
};

function frmLoginGlobals() {
    frmLogin = new kony.ui.Form2({
        "addWidgets": addWidgetsfrmLogin,
        "enabledForIdleTimeout": false,
        "id": "frmLogin",
        "init": AS_Form_facd1bcc86304ead900e90e4590bcbfc,
        "layoutType": kony.flex.FREE_FORM,
        "needAppMenu": true,
        "preShow": AS_Form_a5f07e8a2f264938802afe5dd765f4dc,
        "skin": "CopyslForm0fb5324367aa14b"
    }, {
        "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
        "layoutType": kony.flex.FREE_FORM,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "footerOverlap": false,
        "headerOverlap": false,
        "menuPosition": constants.FORM_MENU_POSITION_AFTER_APPMENU,
        "retainScrollPosition": false,
        "titleBar": true,
        "titleBarSkin": "slTitleBar",
        "windowSoftInputMode": constants.FORM_ADJUST_PAN
    });
};