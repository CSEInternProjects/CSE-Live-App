//Type your code here
function regFailureAndroidCallback() {
    kony.application.dismissLoadingScreen();
    kony.print("regFailureAndroidCallback");
    alert("Check network connection");
}

function onlinePushNotificationAndroidCallback(payLoad) {
    kony.print("onlinePushNotificationAndroidCallback");
    //alert("onlinePushNotificationAndroidCallback");
    //alert(JSON.stringify(payLoad));
    pushHandle(payLoad);
    frmHomePage.flxMoveForNotice.btnClear.setVisibility(true);
}

function offlinePushNotificationAndroidCallback(payLoad) {
    kony.print("offlinePushNotificationAndroidCallback");
    pushHandle(payLoad);
    frmHomePage.flxMoveForNotice.btnClear.setVisibility(true);
}

function ClearButtonForNotificationOnAction() {
    if (kony.net.isNetworkAvailable(constants.NETWORK_TYPE_ANY)) {
        frmHomePage.segPush.removeAll();
        kony.store.removeItem("pushList");
        frmHomePage.btnClear.setVisibility(false);
    }
    //else
    //alert("Please check network connection");
}

function ClearButtonForNotificationOnActionWithOutNetCheck() {
    frmHomePage.segPush.removeAll();
    kony.store.removeItem("pushList");
    frmHomePage.btnClear.setVisibility(false);
}

function pushHandle(payLoad) {
    //frmHomePage.lblNoteTitle.text=payLoad.title;
    frmHomePage.lblNoteData.text = payLoad.content;
    var pushString = kony.store.getItem("pushList");
    var tempStringPayLoad = JSON.stringify(payLoad);
    if (pushString !== null) pushString = ",".concat(pushString);
    else pushString = "";
    pushString = tempStringPayLoad.concat(pushString);
    kony.store.setItem("pushList", pushString);
    pushString = kony.store.getItem("pushList");
    pushString = "{\"dataSet\":[" + pushString + "]}";
    //alert(pushString);
    var test = JSON.parse(pushString);
    var frontNoteSeg = {
        dataSet: []
    };
    frmHomePage.segPush.widgetDataMap = {
        lblSegHeadTitle: "title",
        lblSegContent: "content"
    };
    frmHomePage.segPush.setData(test.dataSet);
    //alert(JSON.stringify(test)); 
}

function unregSuccessAndroidCallback() {
    kony.print("unregSuccessAndroidCallback");
    kony.application.dismissLoadingScreen();
    alert("unregSuccessAndroidCallback");
}

function unregFailureAndroidCallback() {
    kony.print("unregSuccessAndroidCallback");
    kony.print("unregFailureAndroidCallback");
    alert("unregFailureAndroidCallback");
}

function setUnsubcribeTrue() {
    frmHomePage.imgUnsubscribe.setEnabled(true);
}
//var flagForUnsub=0;
function deregister() {
    frmHomePage.imgUnsubscribe.setEnabled(false);
    kony.timer.schedule("forUnsubcribe", setUnsubcribeTrue, 2, false);
    if (kony.net.isNetworkAvailable(constants.NETWORK_TYPE_ANY)) {
        if (true) {
            //flagForUnsub=1;
            kony.application.showLoadingScreen(null, "unsubscribing", constants.LOADING_SCREEN_POSITION_ONLY_CENTER, false, true, {
                shouldShowLabelInBottom: "true",
                separatorHeight: 200
            });
            try {
                messagingClient = KNYMobileFabric.getMessagingService();
            } catch (exception) {
                kony.print("Exception" + exception.message);
                //frmHomePage.imgUnsubscribe.setEnabled(true);
            }
            messagingClient.unregister(function(response) {
                kony.print("Unregistration Success " + JSON.stringify(response));
                if (kony.store.getItem("isFirstTime2") !== null) kony.store.removeItem("isFirstTime2");
                frmHomePage.segPush.setVisibility(false);
                frmHomePage.segPush.removeAll();
                kony.store.removeItem("pushList");
                frmHomePage.flxPush.setVisibility(true);
                frmHomePage.imgUnsubscribe.setVisibility(false);
                // for advance user handling
                /*var tempPrevUser=kony.store.getItem("prevUser");
                kony.store.removeItem("prevUser");
                var tempUserArry=kony.store.getItem("usrArry");
                var tempUserArry1=tempUserArry.slice(0,tempUserArry.search(tempPrevUser));
                var length=tempUserArry.search(tempPrevUser)+tempPrevUser.length;
                var tempUserArry2=tempUserArry.slice(length,tempUserArry.length);
                var setUserArry=tempUserArry1.concat(tempUserArry2);
                kony.store.removeItem("usrArry");
                kony.store.setItem("usrArry", setUserArry);
                */
                kony.store.removeItem("prevUser");
                kony.application.dismissLoadingScreen();
                alert("Unregistration Success ");
                //frmHomePage.imgUnsubscribe.setEnabled(true);
                ClearButtonForNotificationOnAction();
            }, function(error) {
                kony.print("Unregistration Failure " + JSON.stringify(error));
                alert("Unregistration Failure with " + error.httpresponse.responsecode + " error");
                kony.application.dismissLoadingScreen();
                //frmHomePage.imgUnsubscribe.setEnabled(true);
            });
        }
    } else alert("Please check network connection");
}
//Animation
/*function fetchMessages() {
 var start = 0;
 var perpage = 100;
 var jsonBody = {
  "ufid": "test@kony.com",
  "appId": "0c07f417-42ae-4dd8-a738-672872afbf06",
  "startElement": start,
  "elementsPerPage": perpage
 };
 var url =  + "http://productsupport.konylabs.net/api/v1/messages/fetch";
 var request = new kony.net.HttpRequest();
 request.onReadyStateChange = fetchMessagesSucessCalllback;
 request.open(constants.HTTP_METHOD_POST, url, true);
 request.setRequestHeader("Content-Type", "application/json");
 request.setRequestHeader("X-Device-AuthToken", "your_auth_token_if_set");
 request.send(jsonBody);
}
function fetchMessagesSucessCalllback() {
 if (this.readyState == constants.HTTP_READY_STATE_DONE) {
  var fetchMsgs = this.response;
  if (this.status == 200) {
   alert("Fetched All Messages!")
  } else {
   alert("Error fetching push records.");
  }
 }
}
*/