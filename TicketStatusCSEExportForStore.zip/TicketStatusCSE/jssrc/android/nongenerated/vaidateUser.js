//Type your code here
//flagForAlert=1;
function RememberMe() {
    if (kony.store.getItem("user") !== null) {
        frmLogin.txtUser.text = kony.store.getItem("user");
        frmLogin.txtPassWord.text = kony.store.getItem("pass");
    }
}

function ValidateUser() {
    var UFID = EmployeId.toUpperCase();
    if (UFID !== kony.store.getItem("prevUser") && kony.store.getItem("prevUser") !== null) {
        //flagForAlert++;
        deregister();
    } else if (kony.store.getItem("pushList") !== null) {
        /* var pushString=kony.store.getItem("pushList");
     pushString="{\"dataSet\":["+pushString+"]}";
     var test=JSON.parse(pushString);
      var frontNoteSeg={dataSet:[]};
      frmHomePage.segPush.widgetDataMap={lblSegHeadTitle:"title",lblSegContent:"content"};
      frmHomePage.segPush.setData(test.dataSet);
      //flag++;
  */
    }
}

function ValidateUser2() {
    var UFID = EmployeId.toUpperCase();
    if (kony.store.getItem("usrArry") !== null) {
        if (kony.store.getItem("usrArry").search(UFID) !== -1) {
            if (UFID !== kony.store.getItem("prevUser")) {
                deregister();
                callbackAndroidOriphoneRegister();
            }
        } else if (kony.store.getItem("isFirstTime2") !== null) {
            deregister();
        }
    }
}

function logout() {
    frmLogin.txtPassWord.text = "";
    frmLogin.show();
}