function addWidgetsgraphFormMF() {
    graphFormMF.setDefaultUnit(kony.flex.DP);
    var graphWidgetMF = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "80%",
        "id": "graphWidgetMF",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0dp",
        "skin": "slFbox",
        "top": "0dp",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    graphWidgetMF.setDefaultUnit(kony.flex.DP);
    graphWidgetMF.add();
    graphFormMF.add(graphWidgetMF);
};

function graphFormMFGlobals() {
    graphFormMF = new kony.ui.Form2({
        "addWidgets": addWidgetsgraphFormMF,
        "enabledForIdleTimeout": false,
        "id": "graphFormMF",
        "layoutType": kony.flex.FREE_FORM,
        "needAppMenu": true,
        "preShow": AS_Form_09777667d3b94172bd75857b9221a39a,
        "skin": "slForm"
    }, {
        "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
        "layoutType": kony.flex.FREE_FORM,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "retainScrollPosition": false
    });
};