function AS_Image_be4661b6478c4a54a8822b3d9359eb13(eventobject, x, y) {
    return callbackAndroidOriphoneRegister.call(this);
}