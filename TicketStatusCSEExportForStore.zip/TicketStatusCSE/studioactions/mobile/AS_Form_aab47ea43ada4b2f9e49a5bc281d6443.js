function AS_Form_aab47ea43ada4b2f9e49a5bc281d6443(eventobject) {
    frmHomePage.imgOut.setVisibility(true);
    if (kony.store.getItem("pushList") != null) {
        var pushString = kony.store.getItem("pushList");
        pushString = "{\"dataSet\":[" + pushString + "]}";
        var test = JSON.parse(pushString);
        var frontNoteSeg = {
            dataSet: []
        };
        frmHomePage.segPush.widgetDataMap = {
            lblSegHeadTitle: "title",
            lblSegContent: "content"
        };
        frmHomePage.segPush.setData(test.dataSet);
    }
}