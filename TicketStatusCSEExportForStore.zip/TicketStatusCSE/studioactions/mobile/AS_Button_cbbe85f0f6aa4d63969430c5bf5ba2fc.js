function AS_Button_cbbe85f0f6aa4d63969430c5bf5ba2fc(eventobject) {
    return NetWorkCheck.call(this);
}