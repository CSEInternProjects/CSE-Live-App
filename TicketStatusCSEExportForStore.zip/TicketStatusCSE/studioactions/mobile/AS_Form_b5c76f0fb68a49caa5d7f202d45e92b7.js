function AS_Form_b5c76f0fb68a49caa5d7f202d45e92b7(eventobject) {
    return ValidateUser.call(this);
}