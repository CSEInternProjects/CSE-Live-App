function AS_Button_f50c8ada6f4f4e2d88b79e8cce44d283(eventobject) {
    return callbackAndroidOriphoneRegister.call(this);
}