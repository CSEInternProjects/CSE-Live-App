function AS_AppEvents_c4b65b216ab1466584bfad7936dfdec2(eventobject) {
    callbackAndroidOriphoneSetCallbacks();
}