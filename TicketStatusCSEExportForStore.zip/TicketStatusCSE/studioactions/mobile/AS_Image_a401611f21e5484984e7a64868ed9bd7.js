function AS_Image_a401611f21e5484984e7a64868ed9bd7(eventobject, x, y) {
    deregister.call(this);
    ClearButtonForNotificationOnAction.call(this);
}