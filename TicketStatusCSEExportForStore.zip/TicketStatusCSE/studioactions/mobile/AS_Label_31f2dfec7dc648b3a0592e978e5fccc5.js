function AS_Label_31f2dfec7dc648b3a0592e978e5fccc5(eventobject, x, y) {
    kony.application.openURL("https://konysolutions.zendesk.com/agent/filters/39040784");
}