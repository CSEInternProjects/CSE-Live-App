function AS_Form_1fc77aa7fdb4406b9b2f29451eb0e1b8(eventobject) {
    return LMain.call(this);
}