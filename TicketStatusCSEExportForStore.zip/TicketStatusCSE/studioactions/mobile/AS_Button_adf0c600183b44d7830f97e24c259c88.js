function AS_Button_adf0c600183b44d7830f97e24c259c88(eventobject) {
    function MOVE_ACTION____f5e3c9583b7f40b6bb75d68e2921e765_Callback() {
        logout.call(this);
    }
    frmHomePage.flxMoveForNotice.animate(kony.ui.createAnimation({
        "100": {
            "left": "-51%",
            "stepConfig": {
                "timingFunction": kony.anim.EASE
            },
            "rectified": true
        }
    }), {
        "iterationCount": 1,
        "fillMode": kony.anim.FILL_MODE_FORWARDS,
        "duration": 0.025
    }, {
        "animationEnd": MOVE_ACTION____f5e3c9583b7f40b6bb75d68e2921e765_Callback
    });
}