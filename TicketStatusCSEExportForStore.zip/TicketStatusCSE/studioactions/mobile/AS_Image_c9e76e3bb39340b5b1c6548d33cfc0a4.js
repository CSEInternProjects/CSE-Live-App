function AS_Image_c9e76e3bb39340b5b1c6548d33cfc0a4(eventobject, x, y) {
    function MOVE_ACTION____b940dd9e2de548a5b3b529aa4fdc88a9_Callback() {
        frmHomePage.imgOut.setVisibility(true);
    }
    frmHomePage.flxMoveForNotice.animate(kony.ui.createAnimation({
        "100": {
            "left": "-51%",
            "stepConfig": {
                "timingFunction": kony.anim.EASE
            }
        }
    }), {
        "delay": 0,
        "iterationCount": 1,
        "fillMode": kony.anim.FILL_MODE_FORWARDS,
        "duration": 0.25
    }, {
        "animationEnd": MOVE_ACTION____b940dd9e2de548a5b3b529aa4fdc88a9_Callback
    });
}