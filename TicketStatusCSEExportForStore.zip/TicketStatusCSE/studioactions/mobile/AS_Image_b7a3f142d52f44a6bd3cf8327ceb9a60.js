function AS_Image_b7a3f142d52f44a6bd3cf8327ceb9a60(eventobject, x, y) {
    function MOVE_ACTION____a7202bacad4b4a0d9d989aad7ca2164d_Callback() {}
    frmHomePage.flxMoveForNotice.animate(kony.ui.createAnimation({
        "100": {
            "left": "0%",
            "stepConfig": {
                "timingFunction": kony.anim.EASE
            }
        }
    }), {
        "delay": 0,
        "iterationCount": 1,
        "fillMode": kony.anim.FILL_MODE_FORWARDS,
        "duration": 0.25
    }, {
        "animationEnd": MOVE_ACTION____a7202bacad4b4a0d9d989aad7ca2164d_Callback
    });
    frmHomePage.imgOut.setVisibility(false);
    if (kony.store.getItem("isFirstTime2") == null) {
        frmHomePage.flxPush.setVisibility(true);
        //frmHomePage.flxNotePrint.setVisibility(false);
        frmHomePage.segPush.setVisibility(false);
        frmHomePage.imgUnsubscribe.setVisibility(false);
        frmHomePage.forceLayout();
    } else {
        frmHomePage.flxPush.setVisibility(false);
        //frmHomePage.flxNotePrint.setVisibility(true);
        frmHomePage.segPush.setVisibility(true);
        frmHomePage.imgUnsubscribe.setVisibility(true);
    }
    setAnimationForMenu.call(this);
    ValidateUser.call(this);
}