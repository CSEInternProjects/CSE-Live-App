function AS_Button_bf68b4c860a44d02ab328f0536c10a37(eventobject) {
    return ClearButtonForNotificationOnActionWithOutNetCheck.call(this);
}