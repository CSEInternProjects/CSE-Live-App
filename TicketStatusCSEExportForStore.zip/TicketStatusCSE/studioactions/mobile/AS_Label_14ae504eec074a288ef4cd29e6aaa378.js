function AS_Label_14ae504eec074a288ef4cd29e6aaa378(eventobject, x, y) {
    kony.application.openURL("https://konysolutions.zendesk.com/agent/filters/39040784");
}