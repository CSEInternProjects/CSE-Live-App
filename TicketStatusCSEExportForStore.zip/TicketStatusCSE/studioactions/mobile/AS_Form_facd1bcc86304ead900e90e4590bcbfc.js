function AS_Form_facd1bcc86304ead900e90e4590bcbfc(eventobject) {
    minitiateMF.call(this);
    frmLogin.FlexContainer0j95a6b1c5e2749.txtUser.left = "34%";
    frmLogin.FlexContainer0j95a6b1c5e2749.txtUser.top = "18%";
    frmLogin.FlexContainer0j95a6b1c5e2749.txtPassWord.left = "34%";
    frmLogin.FlexContainer0j95a6b1c5e2749.txtPassWord.top = "44%";
    /*frmLogin.FlexContainer0j95a6b1c5e2749.Label0a0ea6f29991248.left="2";
    frmLogin.FlexContainer0j95a6b1c5e2749.Label0a0ea6f29991248.top="45.5";
    frmLogin.FlexContainer0j95a6b1c5e2749.Label0a0ea6f29991248.width="30";
    frmLogin.FlexContainer0j95a6b1c5e2749.Label0a0ea6f29991248.height="10";
    frmLogin.FlexContainer0j95a6b1c5e2749.Label0a0ea6f29991248.z
    */
    frmLogin.forceLayout();
    frmLogin.FlexContainer0j95a6b1c5e2749.forceLayout();
}