function AS_Form_a5f07e8a2f264938802afe5dd765f4dc(eventobject) {
    LMain.call(this);
    RememberMe.call(this);
}