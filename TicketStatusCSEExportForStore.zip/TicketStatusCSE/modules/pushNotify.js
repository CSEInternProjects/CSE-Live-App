//Type your code here
userArry="";
function callbackAndroidOriphoneSetCallbacks()
{
  kony.print("\n\n\n<--------in callbackAndroidSetCallbacks--------->\n\n\n");
 	kony.push.setCallbacks({onsuccessfulregistration: regSuccessAndroidCallback, onfailureregistration: regFailureAndroidCallback,
 						    onlinenotification: onlinePushNotificationAndroidCallback, offlinenotification: offlinePushNotificationAndroidCallback,
 						    onsuccessfulderegistration: unregSuccessAndroidCallback, onfailurederegistration:unregFailureAndroidCallback });
}

function regSuccessAndroidCallback(regId)//what is regid. from where is it by GCM or KMS
{// is regid same as senderID
  kony.print("exe is in regSuccessAndroidCallback "+regId);
  //kony.store.setItem("isFirstTime","true");
  
  var ostype="android";
  pushSubscription(regId, ostype);
}


var messagingClient = null;
function pushSubscription(sid,ostype)
{
 // kony.store.key(index)
  //alert(sid);
var osType = ostype;	
			 
var deviceId = kony.os.deviceInfo().deviceid;
//var UFID="test3@kony.com";//"1123452";
var UFID=EmployeId.toUpperCase();
// To get regID, use kony.push.register() method 

var regId = sid; 
//var UFID = FromHome.ufid.text; what is UFID

try{
	messagingClient = KNYMobileFabric.getMessagingService();
}
catch(exception){
	kony.print("Exception" + exception.message);
}
messagingClient.register(osType,deviceId, regId, UFID, 
	function(response){
	kony.print("Subscription Success " + JSON.stringify(response));
  //alert("Subscription Success " + JSON.stringify(response));
  kony.application.dismissLoadingScreen();
  alert("Subscription Success " );
  kony.store.setItem("prevUser",UFID);
  frmHomePage.flxPush.setVisibility(false);
    frmHomePage.imgUnsubscribe.setVisibility(true);
      frmHomePage.segPush.setVisibility(true);
      frmHomePage.lblNoteTitle.text="not found";
      frmHomePage.lblNoteData.text="";
      frmHomePage.forceLayout();
// for advance user handling
  /*if(userArry.search(UFID)===-1)
  {	userArry=kony.store.getItem("usrArry");
  	userArry=userArry.concat(UFID);
  }
  */
  if(kony.store.getItem("isFirstTime2")===null)
      kony.store.setItem("isFirstTime2","true");
  else
    {
      kony.store.removeItem("isFirstTime2");
      kony.store.setItem("isFirstTime2","true");
    }  
 },
	function(error){
	kony.print("Subscription Failure " + JSON.stringify(error));
  alert("Subscription Failure with " +error.httpresponse.responsecode+" error");
	}
);
  
}

function callbackAndroidOriphoneRegister()
{
  	//flagForUnsub=0;
	kony.application.showLoadingScreen(null, "subscribing", 
	constants.LOADING_SCREEN_POSITION_ONLY_CENTER, false, true, {  
	shouldShowLabelInBottom: "true", separatorHeight: 200} );
    var senderID="803705204247";
  	kony.print("senid:"+senderID);
	var configToRegister = {senderid:senderID};
	kony.push.register(configToRegister);
		//alert("Registration Done !!!");
}

function pushdeRegister()
{
	//kony.print("************ JS unregisterFromAPNS() called *********");
	//kony.application.showLoadingScreen("sknLoading","Deregistering from push notification..",constants.LOADING_SCREEN_POSITION_FULL_SCREEN, true, true,null);
	kony.push.deRegister({});
   	
  //audiencePushSubs=false;
	//editAudience2();
		
}
function setAnimationForMenu()
{
  if(kony.net.isNetworkAvailable(constants.NETWORK_TYPE_ANY))
  {
    
  }
    else
  {
    alert("Please check network connection");
    frmHomePage.flxMoveForNotice.animate(
    kony.ui.createAnimation({
        "100": {
            "left": "-60%",
            "stepConfig": {
                "timingFunction": kony.anim.EASE
            }
        }
    }), {
        "delay": 0,
        "iterationCount": 1,
        "fillMode": kony.anim.FILL_MODE_FORWARDS,
        "duration": 0.25
    }, {
        "animationEnd": function(){}
    }); 
 frmHomePage.imgOut.setVisibility(true);
  }
}