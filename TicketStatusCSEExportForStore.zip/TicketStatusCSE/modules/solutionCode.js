//KonyCSE AppCode.
var i;
var j;
var k;

//HomePage Code Begins.
function LMain() {
    kony.application.showLoadingScreen(loaderSkinCSELive, "Fetching Data...", constants.LOADING_SCREEN_POSITION_ONLY_CENTER, true, true,  {shouldShowLabelInBottom: "true", separatorHeight: 20});
  var x = new Date();
  var x1 = x.toString().split("GMT");
  frmHomePage.timeStampLabel.text = x1[0];

  var urls = ["https://konysolutions.zendesk.com/api/v2/views/39040784/count.json", "https://konysolutions.zendesk.com/api/v2/views/79397997/count.json","https://konysolutions.zendesk.com/api/v2/views/76059937/count.json","https://konysolutions.zendesk.com/api/v2/views/76524808/count.json","https://konysolutions.zendesk.com/api/v2/views/83921348/count.json","https://konysolutions.zendesk.com/api/v2/views/84091227/count.json","https://konysolutions.zendesk.com/api/v2/views/83921568/count.json","https://konysolutions.zendesk.com/api/v2/views/105079228/count.json","https://konysolutions.zendesk.com/api/v2/views/105325107/count.json","https://konysolutions.zendesk.com/api/v2/views/105097048/count.json","https://konysolutions.zendesk.com/api/v2/views/105097088/count.json","https://konysolutions.zendesk.com/api/v2/views/109676948/count.json","https://konysolutions.zendesk.com/api/v2/views/109676848/count.json","https://konysolutions.zendesk.com/api/v2/views/109664928/count.json","https://konysolutions.zendesk.com/api/v2/views/109825467/count.json","https://konysolutions.zendesk.com/api/v2/views/109667768/count.json","https://konysolutions.zendesk.com/api/v2/views/109829007/count.json","https://konysolutions.zendesk.com/api/v2/views/109832507/count.json","https://konysolutions.zendesk.com/api/v2/views/109664228/count.json"];
    for (i = 0; i < urls.length; i++) {
        FetchCount(urls[i]);
    }
  kony.application.dismissLoadingScreen();
}

function FetchCount(urll) {  
 try
    {
      var myhttpheaders={"cors":"true", "dataType":"json","appID":"TicketStatus","Authorization":"Basic bWFub2oudGFtbWFsaUBrb255LmNvbTpEZWNtQDIwMTU="};
	  httpconfig = { "method": "get"};
      var inputParamTable=
          {
              appID:"SampleApp", 
              serviceID:"accountLogin", 
              channel:"rc", 
              httpheaders:myhttpheaders,
              httpconfig:httpconfig
           };
	    var connHandle = kony.net.invokeServiceAsync(
                        urll, 
                        inputParamTable, 
                        zendeskCallback);
		
     }
     catch(err)
     {
	  alert("Error"+err);
     }	
}

function zendeskCallback(status, resulttable) {
    try {
          if (this.readyState == 4 || this.readyState == '4' || status ==400 ){
            var res = resulttable;
           	var respTemp = resulttable.view_count.value.toString().split("."); 
            
            var respViewID = resulttable.view_count.view_id;          
            var fnlRes = respTemp[0]; 
           
            switch (respViewID) {
                
                case 39040784:
                    frmHomePage.mainFlex.openCount.text = fnlRes;
                    break;
                case 79397997:
                    frmHomePage.mainFlex.pendingCount.text = fnlRes;
                    break;
                case 76059937:
                    frmHomePage.mainFlex.unAssignedCount.text = fnlRes;
                    break;
                case 76524808:
                    frmHomePage.mainFlex.no1stCount.text = fnlRes;
                    break;
                case 83921348:
                    frmHomePage.mainFlex.escalatedCount.text = fnlRes;
                    break;
                case 84091227:
                    frmHomePage.mainFlex.hotlistedCount.text = fnlRes;
                    break;
                case 83921568:
                    frmHomePage.mainFlex.othersCount.text = fnlRes;
                    break;
                case 105079228:
                    frmHomePage.mainFlex.openMFMADP.mfopenCount.text = fnlRes;
                    break;
                case 105325107:
                    frmHomePage.mainFlex.openMFMADP.madpopenCount.text = fnlRes;
                    break;
                case 105097048:
                    frmHomePage.mainFlex.pendingMFMADP.mfPending.text = fnlRes;
                    break;
                case 105097088:
                    frmHomePage.mainFlex.pendingMFMADP.madpPending.text = fnlRes;
                    break;
                case 109676948:
                    frmHomePage.mainFlex.no1stMFMADP.mfNo1st.text = fnlRes;
                    break;
                case 109676848:
                    frmHomePage.mainFlex.no1stMFMADP.madpno1st.text  = fnlRes;
                    break;
                case 109664928:
                    frmHomePage.mainFlex.escalatedMFMADP.escMF.text = fnlRes;
                    break;
                case 109825467:
                    frmHomePage.mainFlex.escalatedMFMADP.escMADP.text = fnlRes;
                    break;
                case 109667768:
                    frmHomePage.mainFlex.hotlistedMFMADP.hotMF.text = fnlRes;
                    break;
                case 109829007:
                    frmHomePage.mainFlex.hotlistedMFMADP.hotMADP.text = fnlRes;
                    break;
                case 109832507:
                    frmHomePage.mainFlex.othersMFMADP.othMF.text = fnlRes;
                    break;
                case 109664228:
                    frmHomePage.mainFlex.othersMFMADP.othMADP.text = fnlRes;
                    break;
                default:
                    //frmHomePage.reponseMessage.text = this.response;
                	kony.print("No Matching Found");
            }
            //kony.math.min();
        }
        this.abort();
        return;
    } catch (err) {
        //alert("Exception Caught in Callback:\n " + err.message());
    }
}

//HomePage Code Ends.

//HomePage Auto-Refresh Functionality

kony.timer.schedule("refreshObject", LMain, 120, true );

//MADP Page 1 Code Begins.
function frmAgentDataMain() {
   kony.application.showLoadingScreen(loaderSkinCSELive, "Fetching Data...", constants.LOADING_SCREEN_POSITION_ONLY_CENTER, true, true,  {shouldShowLabelInBottom: "true", separatorHeight: 20});
  var x = new Date();
  var x1 = x.toString().split("GMT");
  frmAgentData.timeStampLabel.text = x1[0];
  var urls = ["https://konysolutions.zendesk.com/api/v2/views/146586127/tickets.json","https://konysolutions.zendesk.com/api/v2/views/146677268/tickets.json","https://konysolutions.zendesk.com/api/v2/views/114098494093/tickets.json","https://konysolutions.zendesk.com/api/v2/views/146677988/tickets.json","https://konysolutions.zendesk.com/api/v2/views/184872787/tickets.json","https://konysolutions.zendesk.com/api/v2/views/147139767/tickets.json","https://konysolutions.zendesk.com/api/v2/views/147139787/tickets.json","https://konysolutions.zendesk.com/api/v2/views/147139807/tickets.json","https://konysolutions.zendesk.com/api/v2/views/147139827/tickets.json","https://konysolutions.zendesk.com/api/v2/views/146710748/tickets.json"];
    for (k = 0; k < urls.length; k++) {
        FetchOpenPendingCount(urls[k]);
    }
  kony.application.dismissLoadingScreen();
}

function FetchOpenPendingCount(urll) {
  try
    {
      
            
	   var myhttpheaders={"cors":"true", "dataType":"json","appID":"TicketStatus","Authorization":"Basic bWFub2oudGFtbWFsaUBrb255LmNvbTpEZWNtQDIwMTU="};
	  httpconfig = { "method": "get"};
      var inputParamTable=
          {
              appID:"SampleApp", 
              serviceID:"accountLogin", 
              channel:"rc", 
              httpheaders:myhttpheaders,
              httpconfig:httpconfig
           };
     
	    var connHandle = kony.net.invokeServiceAsync(
                        urll, 
                        inputParamTable, 
                        openPendingCallback);
		
     }
     catch(err)
     {
	  alert("Error"+err);
     }	
}

function openPendingCallback(status, resulttable) {
    try {
      
      
      var openStatus = 0 ;
      var pendingStatus = 0;
      var totalStatus = 0;
      var assName;
      if (this.readyState == 4 || this.readyState == '4' || status == 400) {
          var res = resulttable;
          var ticketCount = res.tickets.length;
          for(j=0; j<ticketCount; j++){
          	if(res.tickets[j].status.toString() === "open"){
              openStatus = openStatus+1;
            }
            if(res.tickets[j].status.toString() === "pending"){
              pendingStatus = pendingStatus+1;
            }
            	for(var t=0;t<res.tickets[j].custom_fields.length;t++){
            	if(res.tickets[j].custom_fields[t].id == "21145230"){
                  assName = res.tickets[j].custom_fields[t].value;
                }
              }
          }
          
          totalStatus = openStatus + pendingStatus;
          var fnlOpenStatus = openStatus.toString();
          var fnlPendingStatus = pendingStatus.toString();
          var fnlTotalStatus = JSON.stringify(ticketCount);
          
            switch (assName) {
                
                case "jabiulla":
                    frmAgentData.jabiFlex.jabiOpen.text = fnlOpenStatus;
                	frmAgentData.jabiFlex.jabiPending.text = fnlPendingStatus; 
                	frmAgentData.jabiFlex.jabiTotal.text = fnlTotalStatus;
                    break;
                case "anurag_wanjari":
                     frmAgentData.anuragFlex.anuragOpen.text = fnlOpenStatus;
                	frmAgentData.anuragFlex.anuragPending.text = fnlPendingStatus; 
                	frmAgentData.anuragFlex.anuragTotal.text = fnlTotalStatus;
                    break;
                case "lakshmi_vajrapu":
                    frmAgentData.baluFlex.baluOpen.text = fnlOpenStatus;
                	frmAgentData.baluFlex.baluPending.text = fnlPendingStatus; 
                	frmAgentData.baluFlex.baluTotal.text = fnlTotalStatus;
                    break;
                case "guru_pulipati":
                    frmAgentData.guruFlex.guruOpen.text = fnlOpenStatus;
                	frmAgentData.guruFlex.guruPending.text = fnlPendingStatus; 
                	frmAgentData.guruFlex.guruTotal.text = fnlTotalStatus;
                    break;
                case "madhuri_choutkur":
                    frmAgentData.manishFlex.manishOpen.text = fnlOpenStatus;
                	frmAgentData.manishFlex.manishPending.text = fnlPendingStatus; 
                	frmAgentData.manishFlex.manishTotal.text = fnlTotalStatus;
                    break;
                case "nagaraju_yanamadala":
                    frmAgentData.nagarajuFlex.nagarajuOpen.text = fnlOpenStatus;
                	frmAgentData.nagarajuFlex.nagarajuPending.text = fnlPendingStatus; 
                	frmAgentData.nagarajuFlex.nagarajuTotal.text = fnlTotalStatus;
                    break;
                case "naveen_kuppili":
                    frmAgentData.naveenFlex.naveenOpen.text = fnlOpenStatus;
                	frmAgentData.naveenFlex.naveenPending.text = fnlPendingStatus; 
                	frmAgentData.naveenFlex.naveenTotal.text = fnlTotalStatus;
                    break;
                case "radhika_tickets":
                    frmAgentData.radhikaFlex.radhikaOpen.text = fnlOpenStatus;
                	frmAgentData.radhikaFlex.radhikaPending.text = fnlPendingStatus; 
                	frmAgentData.radhikaFlex.radhikaTotal.text = fnlTotalStatus;
                    break;
                case "rashmi":
                    frmAgentData.rashmiMFlex.rashmiMOpen.text = fnlOpenStatus;
                	frmAgentData.rashmiMFlex.rashmiMPending.text = fnlPendingStatus; 
                	frmAgentData.rashmiMFlex.rashmiMTotal.text = fnlTotalStatus;
                    break;
                case "ravikumar":
                    frmAgentData.raviPadFlex.raviPadOpen.text = fnlOpenStatus;
                	frmAgentData.raviPadFlex.raviPadPending.text = fnlPendingStatus; 
                	frmAgentData.raviPadFlex.raviPadTotal.text = fnlTotalStatus;
                    break;
                default:
                    //frmAgentData.reponseMessage.text = this.response;
                kony.print("No Match Found");
            }
            //kony.math.min();
        }
        this.abort();
        return;
    } catch (err) {
        //alert("Exception Caught in Callback:\n " + err.message());
    }
}

//MADP Page 1 Code Ends.



///MADP Page 2 Code Begins.
function frmAgentDataMain2() {
  var x = new Date();
  var x1 = x.toString().split("GMT");
  frmAgentData2.timeStampLabel.text = x1[0];
  var urls = ["https://konysolutions.zendesk.com/api/v2/views/147673907/tickets.json","https://konysolutions.zendesk.com/api/v2/views/147049667/tickets.json","https://konysolutions.zendesk.com/api/v2/views/147206708/tickets.json","https://konysolutions.zendesk.com/api/v2/views/147206788/tickets.json","https://konysolutions.zendesk.com/api/v2/views/147674007/tickets.json","https://konysolutions.zendesk.com/api/v2/views/147206828/tickets.json"];
    for (k = 0; k < urls.length; k++) {
        FetchOpenPendingCount2(urls[k]);
    }
}

function FetchOpenPendingCount2(urll) {
  try
    {
      
            
	   var myhttpheaders={"cors":"true", "dataType":"json","appID":"TicketStatus","Authorization":"Basic bWFub2oudGFtbWFsaUBrb255LmNvbTpEZWNtQDIwMTU="};
	  httpconfig = { "method": "get"};
      var inputParamTable=
          {
              appID:"SampleApp", 
              serviceID:"accountLogin", 
              channel:"rc", 
              httpheaders:myhttpheaders,
              httpconfig:httpconfig
           };
      //alert("input params"+JSON.stringify(inputParamTable));
	    var connHandle = kony.net.invokeServiceAsync(
                        urll, 
                        inputParamTable, 
                        openPendingCallback2);
		
     }
     catch(err)
     {
	  alert("Error"+err);
     }	
}

function openPendingCallback2(status, resulttable) {
    try {
      
      var openStatus = 0 ;
      var pendingStatus = 0;
      var totalStatus = 0;
      var assName;
      if (this.readyState == 4 || this.readyState == '4' || status == 400) {
          var res = resulttable;
         // kony.alert("result table : "+resulttable);
          var ticketCount = res.tickets.length;          
          for(j=0; j<ticketCount; j++){
          	if(res.tickets[j].status.toString() === "open"){
              openStatus = openStatus+1;
            }
            if(res.tickets[j].status.toString() === "pending"){
              pendingStatus = pendingStatus+1;
            }
            	for(var t=0;t<res.tickets[j].custom_fields.length;t++){
                  //kony.print("custom field length : "+res.tickets[j].custom_fields.length);
                  //kony.print("custom field selected : "+res.tickets[j].custom_fields[t].id);
            	if(res.tickets[j].custom_fields[t].id == "21145230"){
                  assName = res.tickets[j].custom_fields[t].value;
                  //kony.print("tammali assignee name" +assName);
                }
              }
          }
          
          totalStatus = openStatus + pendingStatus;
          var fnlOpenStatus = openStatus.toString();
          var fnlPendingStatus = pendingStatus.toString();
          var fnlTotalStatus = JSON.stringify(ticketCount);
          
            switch (assName) {
                
                case "ravi_pyreddy":
                    frmAgentData2.raviPyFlex.raviPyOpen.text = fnlOpenStatus;
                	frmAgentData2.raviPyFlex.raviPyPending.text = fnlPendingStatus; 
                	frmAgentData2.raviPyFlex.raviPyTotal.text = fnlTotalStatus;
                    break;
                case "ravinder_beecham":
                     frmAgentData2.raviBeFlex.raviBeOpen.text = fnlOpenStatus;
                	frmAgentData2.raviBeFlex.raviBePending.text = fnlPendingStatus; 
                	frmAgentData2.raviBeFlex.raviBeTotal.text = fnlTotalStatus;
                    break;
                case "rojalin":
                    frmAgentData2.rojalinFlex.rojalinOpen.text = fnlOpenStatus;
                	frmAgentData2.rojalinFlex.rojalinPending.text = fnlPendingStatus; 
                	frmAgentData2.rojalinFlex.rojalinTotal.text = fnlTotalStatus;
                    break;
                case "santhoshn":
                    frmAgentData2.santoshNFlex.santoshNOpen.text = fnlOpenStatus;
                	frmAgentData2.santoshNFlex.santoshNPending.text = fnlPendingStatus; 
                	frmAgentData2.santoshNFlex.santoshNTotal.text = fnlTotalStatus;
                    break;
                case "sirisha_m":
                    frmAgentData2.sirishaFlex.sirishaOpen.text = fnlOpenStatus;
                	frmAgentData2.sirishaFlex.sirishaPending.text = fnlPendingStatus; 
                	frmAgentData2.sirishaFlex.sirishaTotal.text = fnlTotalStatus;
                    break;
                case "johnvinodh_talluri":
                    frmAgentData2.johnvinodhFlex.johnvinodhOpen.text = fnlOpenStatus;
                	frmAgentData2.johnvinodhFlex.johnvinodhPending.text = fnlPendingStatus; 
                	frmAgentData2.johnvinodhFlex.johnvinodhTotal.text = fnlTotalStatus;
                    break;
                default:
                    //frmAgentData.reponseMessage.text = this.response;
                kony.print("No Match Found");
            }
            //kony.math.min();
        }
        this.abort();
        return;
    } catch (err) {
        //alert("Exception Caught in Callback:\n " + err.message());
    }
}

//MF Page  Code Begins.
function frmAgentDataMainMF() {
  var x = new Date();
  var x1 = x.toString().split("GMT");
  frmAgentDataMF.timeStampLabel.text = x1[0];
  var urls = ["https://konysolutions.zendesk.com/api/v2/views/147691727/tickets.json","https://konysolutions.zendesk.com/api/v2/views/147691747/tickets.json","https://konysolutions.zendesk.com/api/v2/views/147691787/tickets.json","https://konysolutions.zendesk.com/api/v2/views/147691827/tickets.json","https://konysolutions.zendesk.com/api/v2/views/147691847/tickets.json","https://konysolutions.zendesk.com/api/v2/views/147691887/tickets.json","https://konysolutions.zendesk.com/api/v2/views/147691907/tickets.json","https://konysolutions.zendesk.com/api/v2/views/146677968/tickets.json","https://konysolutions.zendesk.com/api/v2/views/147691947/tickets.json","https://konysolutions.zendesk.com/api/v2/views/147691967/tickets.json","https://konysolutions.zendesk.com/api/v2/views/160792027/tickets.json"];
    for (k = 0; k < urls.length; k++) {
        FetchOpenPendingCountMF(urls[k]);
    }
}

function FetchOpenPendingCountMF(urll) {
  try
    {
      
            
	   var myhttpheaders={"cors":"true", "dataType":"json","appID":"TicketStatus","Authorization":"Basic bWFub2oudGFtbWFsaUBrb255LmNvbTpEZWNtQDIwMTU="};
	  httpconfig = { "method": "get"};
      var inputParamTable=
          {
              appID:"SampleApp", 
              serviceID:"accountLogin", 
              channel:"rc", 
              httpheaders:myhttpheaders,
              httpconfig:httpconfig
           };
      //alert("input params"+JSON.stringify(inputParamTable));
	    var connHandle = kony.net.invokeServiceAsync(
                        urll, 
                        inputParamTable, 
                        openPendingCallbackMF);
		
     }
     catch(err)
     {
	  alert("Error"+err);
     }	
}

function openPendingCallbackMF(status, resulttable) {
    try {
      
      var openStatus = 0 ;
      var pendingStatus = 0;
      var totalStatus = 0;
      var assName;
      if (this.readyState == 4 || this.readyState == '4' || status == 400) {
          var res = resulttable;
         // kony.alert("result table : "+resulttable);
          var ticketCount = res.tickets.length;          
          for(j=0; j<ticketCount; j++){
          	if(res.tickets[j].status.toString() === "open"){
              openStatus = openStatus+1;
            }
            if(res.tickets[j].status.toString() === "pending"){
              pendingStatus = pendingStatus+1;
            }
            	for(var t=0;t<res.tickets[j].custom_fields.length;t++){
                  //kony.print("custom field length : "+res.tickets[j].custom_fields.length);
                  //kony.print("custom field selected : "+res.tickets[j].custom_fields[t].id);
            	if(res.tickets[j].custom_fields[t].id == "21145230"){
                  assName = res.tickets[j].custom_fields[t].value;
                  //kony.print("tammali assignee name" +assName);
                }
              }
          }
          
          totalStatus = openStatus + pendingStatus;
          var fnlOpenStatus = openStatus.toString();
          var fnlPendingStatus = pendingStatus.toString();
          var fnlTotalStatus = JSON.stringify(ticketCount);
          
            switch (assName) {
                
                case "arif":
                    frmAgentDataMF.arifFlex.arifOpen.text = fnlOpenStatus;
                	frmAgentDataMF.arifFlex.arifPending.text = fnlPendingStatus; 
                	frmAgentDataMF.arifFlex.arifTotal.text = fnlTotalStatus;
                    break;
                case "kushal":
                    frmAgentDataMF.kushalFlex.kushalOpen.text = fnlOpenStatus;
                	frmAgentDataMF.kushalFlex.kushalPending.text = fnlPendingStatus; 
                	frmAgentDataMF.kushalFlex.kushalTotal.text = fnlTotalStatus;
                    break;
                case "sreekanth_madamanchi":
                    frmAgentDataMF.srikanthMFlex.srikanthMOpen.text = fnlOpenStatus;
                	frmAgentDataMF.srikanthMFlex.srikanthMPending.text = fnlPendingStatus; 
                	frmAgentDataMF.srikanthMFlex.srikanthMTotal.text = fnlTotalStatus;
                    break;
                case "harish_tammineddi":
                    frmAgentDataMF.harishFlex.harishOpen.text = fnlOpenStatus;
                	frmAgentDataMF.harishFlex.harishPending.text = fnlPendingStatus; 
                	frmAgentDataMF.harishFlex.harishTotal.text = fnlTotalStatus;
                    break;
                case "srikanth_donavalli":
                    frmAgentDataMF.srikanthDFlex.srikanthDOpen.text = fnlOpenStatus;
                	frmAgentDataMF.srikanthDFlex.srikanthDPending.text = fnlPendingStatus; 
                	frmAgentDataMF.srikanthDFlex.srikanthDTotal.text = fnlTotalStatus;
                    break;
                case "suresh_balivada":
                    frmAgentDataMF.sureshBFlex.sureshBOpen.text = fnlOpenStatus;
                	frmAgentDataMF.sureshBFlex.sureshBPending.text = fnlPendingStatus; 
                	frmAgentDataMF.sureshBFlex.sureshBTotal.text = fnlTotalStatus;
                    break;
                case "sana-tickets":
                    frmAgentDataMF.sanaFlex.sanaOpen.text = fnlOpenStatus;
                	frmAgentDataMF.sanaFlex.sanaPending.text = fnlPendingStatus; 
                	frmAgentDataMF.sanaFlex.sanaTotal.text = fnlTotalStatus;
                    break;
                case "pothuraju_gorre":
                    frmAgentDataMF.ramanaFlex.ramanaOpen.text = fnlOpenStatus;
                	frmAgentDataMF.ramanaFlex.ramanaPending.text = fnlPendingStatus; 
                	frmAgentDataMF.ramanaFlex.ramanaTotal.text = fnlTotalStatus;
                    break;
                 case "thilak":
                    frmAgentDataMF.thilakFlex.thilakOpen.text = fnlOpenStatus;
                	frmAgentDataMF.thilakFlex.thilakPending.text = fnlPendingStatus; 
                	frmAgentDataMF.thilakFlex.thilakTotal.text = fnlTotalStatus;
                    break;
                 case "naresh_nalamolu":
                    frmAgentDataMF.nareshFlex.nareshOpen.text = fnlOpenStatus;
                	frmAgentDataMF.nareshFlex.nareshPending.text = fnlPendingStatus; 
                	frmAgentDataMF.nareshFlex.nareshTotal.text = fnlTotalStatus;
                    break;
                case "mallikarjuna_anegondi":
                    frmAgentDataMF.mallikarjunaFlex.mallikarjunaOpen.text = fnlOpenStatus;
                	frmAgentDataMF.mallikarjunaFlex.mallikarjunaPending.text = fnlPendingStatus; 
                	frmAgentDataMF.mallikarjunaFlex.mallikarjunaTotal.text = fnlTotalStatus;
                    break;
                default:
                    //frmAgentData.reponseMessage.text = this.response;
                kony.print("No Match Found");
            }
            //kony.math.min();
        }
        this.abort();
        return;
    } catch (err) {
        //alert("Exception Caught in Callback:\n " + err.message());
    }
}



