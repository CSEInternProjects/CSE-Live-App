//Type your code here
//MF Page  Code Begins.
var openGraph = [];
var penGraph = [];
var i;
var j;
var k;
function frmAgentDataMainMFGraph() {
  var x = new Date();
  var x1 = x.toString().split("GMT");
  frmAgentDataMF.timeStampLabel.text = x1[0];
  var urls = ["https://konysolutions.zendesk.com/api/v2/views/147691727/tickets.json","https://konysolutions.zendesk.com/api/v2/views/147691747/tickets.json","https://konysolutions.zendesk.com/api/v2/views/147691787/tickets.json","https://konysolutions.zendesk.com/api/v2/views/147691827/tickets.json","https://konysolutions.zendesk.com/api/v2/views/147691847/tickets.json","https://konysolutions.zendesk.com/api/v2/views/147691887/tickets.json","https://konysolutions.zendesk.com/api/v2/views/147691907/tickets.json","https://konysolutions.zendesk.com/api/v2/views/147673947/tickets.json","https://konysolutions.zendesk.com/api/v2/views/147691947/tickets.json","https://konysolutions.zendesk.com/api/v2/views/147691967/tickets.json","https://konysolutions.zendesk.com/api/v2/views/160792027/tickets.json"];
    for (k = 0; k < urls.length; k++) {
        FetchOpenPendingCountMFGraph(urls[k]);
    }
}

function FetchOpenPendingCountMFGraph(urll) {
  try
    {
      
            
	   var myhttpheaders={"cors":"true", "dataType":"json","appID":"TicketStatus","Authorization":"Basic bWFub2oudGFtbWFsaUBrb255LmNvbTpEZWNtQDIwMTU="};
	  httpconfig = { "method": "get"};
      var inputParamTable=
          {
              appID:"SampleApp", 
              serviceID:"accountLogin", 
              channel:"rc", 
              httpheaders:myhttpheaders,
              httpconfig:httpconfig
           };
      //alert("input params"+JSON.stringify(inputParamTable));
	    var connHandle = kony.net.invokeServiceAsync(
                        urll, 
                        inputParamTable, 
                        openPendingCallbackMFGraph);
		
     }
     catch(err)
     {
	  alert("Error"+err);
     }	
}

function openPendingCallbackMFGraph(status, resulttable) {
    try {
      
      var openStatus = 0 ;
      var pendingStatus = 0;
      var totalStatus = 0;
      var assName;
      if (this.readyState == 4 || this.readyState == '4' || status == 400) {
          var res = resulttable;
         // kony.alert("result table : "+resulttable);
          var ticketCount = res.tickets.length;          
          for(j=0; j<ticketCount; j++){
          	if(res.tickets[j].status.toString() === "open"){
              openStatus = openStatus+1;
            }
            if(res.tickets[j].status.toString() === "pending"){
              pendingStatus = pendingStatus+1;
            }
            	for(var t=0;t<res.tickets[j].custom_fields.length;t++){
                  //kony.print("custom field length : "+res.tickets[j].custom_fields.length);
                  //kony.print("custom field selected : "+res.tickets[j].custom_fields[t].id);
            	if(res.tickets[j].custom_fields[t].id == "21145230"){
                  assName = res.tickets[j].custom_fields[t].value;
                  //kony.print("tammali assignee name" +assName);
                }
              }
          }
          
          totalStatus = openStatus + pendingStatus;
          var fnlOpenStatus = openStatus.toString();
          var fnlPendingStatus = pendingStatus.toString();
          var fnlTotalStatus = JSON.stringify(ticketCount);
          
            switch (assName) {
                
                case "arif":
                    //openGraph.push(fnlOpenStatus);
                	//penGraph.push(fnlOpenStatus);
                    openGraph.splice(0,fnlOpenStatus);
               		penGraph.splice(0,fnlOpenStatus);
                    break;
                case "kushal":
                    openGraph.splice(1,fnlOpenStatus);
               		penGraph.splice(1,fnlOpenStatus);
                    break;
                case "sreekanth_madamanchi":
                    openGraph.splice(2,fnlOpenStatus);
               		penGraph.splice(2,fnlOpenStatus);
                    break;
                case "harish_tammineddi":
                    openGraph.splice(3,fnlOpenStatus);
               		penGraph.splice(3,fnlOpenStatus);
                    break;
                case "srikanth_donavalli":
                    openGraph.splice(4,fnlOpenStatus);
               		penGraph.splice(4,fnlOpenStatus);
                    break;
                case "suresh_balivada":
                    openGraph.splice(5,fnlOpenStatus);
               		penGraph.splice(5,fnlOpenStatus);
                    break;
                case "sana-tickets":
                    openGraph.splice(6,fnlOpenStatus);
               		penGraph.splice(6,fnlOpenStatus);
                    break;
                case "venkat_ramana":
                    openGraph.splice(7,fnlOpenStatus);
               		penGraph.splice(7,fnlOpenStatus);
                    break;
                 case "thilak":
                    openGraph.splice(8,fnlOpenStatus);
               		penGraph.splice(8,fnlOpenStatus);
                    break;
                 case "naresh_nalamolu":
                    openGraph.splice(9,fnlOpenStatus);
               		penGraph.splice(9,fnlOpenStatus);
                    break;
                case "mallikarjuna_anegondi":
                    openGraph.splice(10,fnlOpenStatus);
               		openGraph.splice(10,fnlOpenStatus);
                    break;
                default:
                    //frmAgentData.reponseMessage.text = this.response;
                kony.print("No Match Found");
            }
        kdv_createChartWidgetMF();
        kony.print(openGraph);
        kony.print(penGraph);
            //kony.math.min();
        }
        this.abort();
        return;
    } catch (err) {
        //alert("Exception Caught in Callback:\n " + err.message());
    }
}


//creating chart widget...
function kdv_createChartWidgetMF()
{
    var chartObj = kdv_createBarChartJSObjectMF();
    
    var chartWidget = new kony.ui.Chart2D3D({
		  "id": "chartid",
		  "isVisible": true
		   }, {
		  "widgetAlignment": constants.WIDGET_ALIGN_CENTER,
		  "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
		  "containerWeight": 100,
      	  "hExpand": true,
          "vExpand": true
		  },
		  chartObj);
    //return chartWidget;
  graphFormMF.graphWidgetMF.add(chartWidget);
}

//creating chart object with chart properties and chart data...
function kdv_createBarChartJSObjectMF () {
    var chartInfo = {
        "chartProperties": {
            "chartHeight": 100,
            "title": {
                "text": "CSE Live",
                "font": {
                    "size": [40],
                    "family": ["Verdana"],
                    "style": ["bold"],
                    "color": ["0xffffffff"]
                },
                "containerWt": 12,
                "background": {
                    "fillType": "gradient",
                    "color": ["0x070707ff", "0x323232FF"]
                }
            },
            "layerArea": {
                "background": {
                    "fillType": "gradient",
                    "color": ["0x070707ff", "0x323232FF"]
                }
            },
            "axis": {
                "xAxis": {
                    "title": {
                        "text": "Ticket Count",
                        "font": {
                            "size": [40],
                            "family": ["Verdana"],
                            "style": ["bold"],
                            "color": ["0xffffffff"]
                        },
                        "margin": [0, 0, 15, 0]
                    },
                    "scale": {
                        "minValue": 0,
                        "maxValue": 100,
                        "majorInterval": 10
                    },
                    "axisLine": {
                        "visible": false
                    },
                    "labels": {
                        "font": {
                            "size": [35],
                            "family": ["Verdana"],
                            "style": ["normal"],
                            "color": ["0xffffffff"]
                        }
                    }
                },
                "yAxis": {
                    "title": {
                        "text": "CSE Engineer",
                        "font": {
                            "size": [40],
                            "family": ["Verdana"],
                            "style": ["bold"],
                            "color": ["0xffffffff"]
                        }
                    },
                    "axisLine": {
                        "visible": false
                    },
                    "labels": {
                        "font": {
                            "size": [35],
                            "family": ["Verdana"],
                            "style": ["normal"],
                            "color": ["0xffffffff"]
                        }
                    }
                }
            },
            "grid": {
                "type": ["xAxisMajorGrid", "xAxisMinorGrid"],
                "xAxisMajorGrid": {
                    "visible": false
                },
                "xAxisMinorGrid": {
                    "visible": false
                },
                "background": {
                    "fillType": "alternateColor",
                    "alternateColorPattern": "xMajorMinor",
                    "transparency": 80,
                    "color": ["0x323232FF", "0x070707FF"]
                }
            },
            "drawEntities": ["axis", "grid", "barChart"],
            "barChart": {
                "columnId":[0, 1],
                "graphType":"stacked",
                "bar": {
                    "fillType": ["color"],
                    "color": ["0x3291cbff", "0x0018A8FF"]
                },
                "border": {
                    "visible": true,
                    "line": {
                        "width":[3],
                        "tranparency":[0],
                        "color": ["0x3291cbff","0x0018A8FF"]
                    }
                },
                "dataLabels": {
                    "placement": "center",
                    "font": {
                        "size": [35],
                        "family": ["Verdana"],
                        "style": ["normal"],
                        "color": ["0xffffffff"]
                    }
                }
            }
        },
        "chartData": {
            "rowNames": {
                "values": ["Arif", "Kushal", "Sreekanth M", "Harish", "Srikanth D", "Suresh B", "Sana", "Ramana", "Thilak", "Naresh N","Mallikarjuna"]
            },
            "columnNames": {
                "values": ["c1", "c2"]
            },
            "data": {
                "c1": openGraph,
                "c2": penGraph
            }
        }
    };
    return chartInfo;
}
